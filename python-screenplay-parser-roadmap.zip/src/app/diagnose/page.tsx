"use client";

import { useEffect, useState } from "react";
import type { DatasetReport } from "@/lib/parser/types";
import { Badge, Card, EmptyState, SectionTitle, Spinner, Stat } from "@/components/ui";

export default function DiagnosePage() {
  const [report, setReport] = useState<DatasetReport | null>(null);
  const [preview, setPreview] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/diagnose")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) {
          setReport(d.report);
          setPreview(d.preview ?? []);
        } else setError(d.error);
      })
      .catch(() => setError("진단 API 호출 실패"))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="py-20">
        <Spinner label="movies.md 진단 중…" />
      </div>
    );
  }
  if (error || !report) return <EmptyState>{error ?? "진단 결과 없음"}</EmptyState>;

  const checks: { label: string; ok: boolean; detail: string }[] = [
    { label: "실제 Markdown 여부", ok: report.encoding.includes("utf-8"), detail: report.encoding },
    { label: "영화별 구분자 일관성", ok: report.separatorConsistent, detail: report.separator ?? "없음" },
    { label: "줄바꿈 인코딩", ok: report.lineEndings !== "mixed", detail: report.lineEndings },
    { label: "씬 헤딩 시간 정보", ok: report.headingWithoutTime === 0, detail: `${report.headingWithTime}/${report.headingWithTime + report.headingWithoutTime}` },
    { label: "깨진 문자", ok: report.suspiciousChars === 0, detail: `${report.suspiciousChars}개` },
    { label: "중복 원문", ok: report.duplicateLines === 0, detail: `${report.duplicateLines}줄` },
  ];

  return (
    <div className="space-y-8">
      <SectionTitle sub="Phase 1 — dataset_report.json 동일 구조">
        파일 상태 진단
      </SectionTitle>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="movies" value={report.movies} tone="amber" />
        <Stat label="scenes detected" value={report.scenesDetected} tone="sky" />
        <Stat label="file size" value={`${(report.fileSizeBytes / 1024).toFixed(1)} KB`} />
        <Stat label="lines" value={report.lineCount} />
      </div>

      <Card className="px-5 py-5">
        <h3 className="mb-3 text-sm font-semibold text-zinc-100">확인 항목</h3>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
          {checks.map((c) => (
            <div
              key={c.label}
              className="flex items-center justify-between gap-2 rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2.5"
            >
              <div>
                <div className="text-xs font-medium text-zinc-200">{c.label}</div>
                <div className="font-mono text-[10px] text-zinc-500">{c.detail}</div>
              </div>
              <Badge tone={c.ok ? "emerald" : "rose"}>{c.ok ? "OK" : "위험"}</Badge>
            </div>
          ))}
        </div>
      </Card>

      <Card className="px-5 py-5">
        <h3 className="mb-3 text-sm font-semibold text-zinc-100">parsing_risks</h3>
        {report.parsingRisks.length ? (
          <ul className="space-y-2">
            {report.parsingRisks.map((r) => (
              <li key={r} className="flex items-center gap-2 text-xs text-rose-300">
                <span className="flex h-5 w-5 items-center justify-center rounded-full bg-rose-500/10 text-[10px] ring-1 ring-rose-500/30">!</span>
                {r}
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-xs text-emerald-300">위험 요소 없음</div>
        )}
      </Card>

      <Card>
        <div className="flex items-center justify-between border-b border-zinc-800 px-5 py-3">
          <h3 className="text-sm font-semibold text-zinc-100">movies.md Raw Source 미리보기</h3>
          <Badge tone="zinc">data/movies.md · 보존 대상</Badge>
        </div>
        <pre className="max-h-96 overflow-auto px-5 py-4 font-mono text-[11px] leading-relaxed text-zinc-400">
          {preview.map((l, i) => (
            <div key={i} className={l.includes("INT. STARBUCKS") ? "bg-amber-500/10 text-amber-200" : ""}>
              <span className="mr-3 select-none text-zinc-700">{String(i + 1).padStart(3, "0")}</span>
              {l || " "}
            </div>
          ))}
        </pre>
      </Card>
    </div>
  );
}
