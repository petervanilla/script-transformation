"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Badge, Button, Card, EmptyState, SectionTitle, Spinner } from "@/components/ui";
import { ACCEPT_ATTR } from "@/lib/formats";

interface SourceRow {
  id: string;
  originalName: string;
  format: string;
  sizeBytes: number;
  title: string | null;
  movieCount: number | null;
  sceneCount: number | null;
  charCount: number | null;
  status: string | null;
  createdAt: string;
}

const FMT_ICON: Record<string, string> = {
  pdf: "📕",
  docx: "📘",
  json: "📗",
  txt: "📄",
  md: "📄",
  markdown: "📄",
};

export default function UploadPage() {
  const [dragOver, setDragOver] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ movies: { title: string; slug: string; stats: unknown }[] } | null>(null);
  const [sources, setSources] = useState<SourceRow[]>([]);
  const [loaded, setLoaded] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const loadSources = useCallback(async () => {
    try {
      const res = await fetch("/api/upload");
      const d = await res.json();
      if (d.ok) setSources(d.sources);
    } finally {
      setLoaded(true);
    }
  }, []);

  // load on mount
  useEffect(() => {
    loadSources();
  }, [loadSources]);

  const upload = async (file: File) => {
    setBusy(true);
    setError(null);
    setResult(null);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      setResult({ movies: data.movies });
      await loadSources();
    } catch (e) {
      setError(e instanceof Error ? e.message : "업로드 실패");
    } finally {
      setBusy(false);
    }
  };

  const onFiles = (files: FileList | null) => {
    if (files && files[0]) upload(files[0]);
  };

  const remove = async (id: string) => {
    if (!confirm("이 소스와 생성된 그래프를 삭제할까요?")) return;
    await fetch(`/api/sources?id=${id}`, { method: "DELETE" });
    await loadSources();
  };

  const fmtSize = (b: number) => (b < 1024 ? `${b} B` : `${(b / 1024).toFixed(1)} KB`);

  return (
    <div className="space-y-6">
      <SectionTitle sub="JSON · Word(.docx) · txt · PDF · Markdown 를 끌어다 놓으면 자동으로 텍스트 추출 → Scene/Beat 파싱 → Director Knowledge Graph 생성">
        파일 업로드 · 다운로드
      </SectionTitle>

      {/* Drop zone */}
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          onFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        className={`flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed py-16 text-center transition ${
          dragOver
            ? "border-amber-500 bg-amber-500/5"
            : "border-zinc-700 bg-zinc-900/40 hover:border-zinc-500 hover:bg-zinc-900/70"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept={ACCEPT_ATTR}
          className="hidden"
          onChange={(e) => onFiles(e.target.files)}
        />
        <div className="text-5xl">{busy ? "⏳" : "🗂️"}</div>
        {busy ? (
          <Spinner label="텍스트 추출 → 파싱 → DKG 생성 중…" />
        ) : (
          <>
            <div className="text-base font-semibold text-zinc-100">
              {dragOver ? "여기에 놓으세요" : "대본 파일을 끌어다 놓거나 클릭해서 선택"}
            </div>
            <div className="text-xs text-zinc-500">
              지원 형식: .txt · .md · .json · .pdf · .docx
            </div>
            <div className="mt-1 flex gap-1.5">
              {["txt", "md", "json", "pdf", "docx"].map((f) => (
                <Badge key={f} tone="zinc">
                  {FMT_ICON[f] ?? "📄"} {f}
                </Badge>
              ))}
            </div>
          </>
        )}
      </div>

      {error && (
        <Card className="border-rose-500/30 px-4 py-3 text-xs text-rose-300">{error}</Card>
      )}

      {result && (
        <Card className="border-emerald-500/30 bg-emerald-950/10 px-4 py-3">
          <div className="text-xs font-semibold text-emerald-300">
            ✓ 변환 완료 — Director Knowledge Graph 생성됨
          </div>
          <div className="mt-2 flex flex-wrap gap-2">
            {result.movies.map((m) => (
              <div key={m.slug} className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2 text-xs">
                <span className="font-semibold text-zinc-100">{m.title}</span>
                <span className="ml-2 text-zinc-500">{JSON.stringify(m.stats)}</span>
              </div>
            ))}
            <a href="/graph">
              <Button variant="success" className="ml-auto">지식 그래프 보기 →</Button>
            </a>
          </div>
        </Card>
      )}

      {/* Sources list */}
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-zinc-100">업로드된 소스 ({sources.length})</h3>
          <Button variant="ghost" onClick={() => loadSources()}>
            ↻ 새로고침
          </Button>
        </div>

        {!loaded ? (
          <Spinner />
        ) : sources.length === 0 ? (
          <EmptyState>
            <div className="text-3xl">📭</div>
            <div>아직 업로드된 파일이 없습니다</div>
          </EmptyState>
        ) : (
          <div className="space-y-2">
            {sources.map((s) => (
              <Card key={s.id} className="px-4 py-3.5">
                <div className="flex flex-wrap items-center gap-3">
                  <span className="text-xl">{FMT_ICON[s.format] ?? "📄"}</span>
                  <div className="min-w-0">
                    <div className="truncate text-sm font-semibold text-zinc-100">
                      {s.originalName}
                    </div>
                    <div className="text-[11px] text-zinc-500">
                      {s.title ?? "제목 없음"} · {s.format.toUpperCase()} · {fmtSize(s.sizeBytes)} · {s.movieCount ?? 0} movies · {s.sceneCount ?? 0} scenes
                    </div>
                  </div>
                  <div className="ml-auto flex flex-wrap items-center gap-1.5">
                    <Badge tone={s.status === "parsed" ? "emerald" : "amber"}>{s.status}</Badge>
                    <a
                      href={`/api/sources/${s.id}/download?type=original`}
                      className="rounded-md border border-zinc-700 px-2 py-1 text-[10px] text-zinc-300 transition hover:border-zinc-500"
                    >
                      원본
                    </a>
                    <a
                      href={`/api/sources/${s.id}/download?type=text`}
                      className="rounded-md border border-zinc-700 px-2 py-1 text-[10px] text-zinc-300 transition hover:border-zinc-500"
                    >
                      TXT
                    </a>
                    <a
                      href={`/api/sources/${s.id}/download?type=json`}
                      className="rounded-md border border-zinc-700 px-2 py-1 text-[10px] text-zinc-300 transition hover:border-zinc-500"
                    >
                      파싱 JSON
                    </a>
                    <a
                      href={`/api/sources/${s.id}/download?type=graph`}
                      className="rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-[10px] text-amber-300 transition hover:bg-amber-500/20"
                    >
                      DKG JSON
                    </a>
                    <a href="/graph">
                      <span className="rounded-md border border-zinc-700 px-2 py-1 text-[10px] text-sky-300 transition hover:border-sky-500/50">
                        그래프 →
                      </span>
                    </a>
                    <button
                      onClick={() => remove(s.id)}
                      className="rounded-md px-2 py-1 text-[10px] text-rose-400 transition hover:bg-rose-500/10"
                    >
                      삭제
                    </button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
