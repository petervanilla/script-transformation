"use client";

import { useEffect, useState } from "react";
import type { DirectorGraph } from "@/lib/dkg/types";
import { GraphView } from "@/components/GraphView";
import { Badge, Button, Card, EmptyState, SectionTitle, Spinner } from "@/components/ui";

export default function GraphPage() {
  const [graph, setGraph] = useState<DirectorGraph | null>(null);
  const [movies, setMovies] = useState<{ slug: string; title: string }[]>([]);
  const [sourceId, setSourceId] = useState<string | null>(null);
  const [activeSlug, setActiveSlug] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sampleMode, setSampleMode] = useState(false);

  const load = async (sid: string | null, slug: string | null, sample = false) => {
    setLoading(true);
    setError(null);
    try {
      const qs = new URLSearchParams();
      if (sample) qs.set("sample", "1");
      if (sid) qs.set("sourceId", sid);
      if (slug) qs.set("movieSlug", slug);
      const res = await fetch(`/api/graph?${qs.toString()}`);
      const d = await res.json();
      if (!d.ok) throw new Error(d.error);
      setGraph(d.graph);
      setMovies(d.movies ?? []);
      setSourceId(d.source?.id ?? null);
      if (!slug && d.movies?.length) setActiveSlug(d.movies[0].slug);
    } catch (e) {
      setError(e instanceof Error ? e.message : "그래프 로드 실패");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(null, null);
  }, []);

  const pickMovie = (slug: string) => {
    setActiveSlug(slug);
    load(sourceId, slug, sampleMode);
  };

  const useSample = () => {
    setSampleMode(true);
    load(null, null, true);
  };
  const useUploaded = () => {
    setSampleMode(false);
    load(null, null, false);
  };

  return (
    <div className="space-y-6">
      <SectionTitle
        sub="Movie → Sequence → Scene → Beat → Intent → 감정·카메라·블로킹·조명·구도·편집·음악·프롬프트·모션. 감독의 사고 과정을 저장하는 관계형 그래프."
        right={
          <div className="flex items-center gap-2">
            {sampleMode ? (
              <Button variant="ghost" onClick={useUploaded}>
                내 업로드 보기
              </Button>
            ) : (
              <Button variant="outline" onClick={useSample}>
                샘플 데이터로 보기
              </Button>
            )}
            {sourceId && (
              <a href={`/api/sources/${sourceId}/download?type=graph${activeSlug ? `&movie=${activeSlug}` : ""}`}>
                <Button variant="outline">⬇ DKG JSON</Button>
              </a>
            )}
          </div>
        }
      >
        Director Knowledge Graph
        {sampleMode && <Badge tone="amber" className="ml-2">샘플</Badge>}
      </SectionTitle>

      {movies.length > 1 && (
        <div className="flex flex-wrap gap-2">
          {movies.map((m) => (
            <button
              key={m.slug}
              onClick={() => pickMovie(m.slug)}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition ${
                activeSlug === m.slug
                  ? "bg-amber-500/15 text-amber-300 ring-1 ring-amber-500/30"
                  : "bg-zinc-800/60 text-zinc-400 hover:text-zinc-200"
              }`}
            >
              {m.title}
            </button>
          ))}
        </div>
      )}

      {loading ? (
        <div className="py-20">
          <Spinner label="지식 그래프 로드 중…" />
        </div>
      ) : error || !graph ? (
        <EmptyState>
          <div className="text-3xl">🕸️</div>
          <div className="mt-1">{error ?? "그래프 없음"}</div>
          <div className="mt-1 text-[11px] text-zinc-600">
            먼저 <a href="/upload" className="text-amber-400 underline">업로드 페이지</a>에서 대본 파일을 변환하거나,
          </div>
          <Button variant="outline" className="mt-3" onClick={useSample}>
            샘플 데이터로 그래프 체험하기 →
          </Button>
        </EmptyState>
      ) : (
        <div className="space-y-4">
          {/* stats */}
          <div className="grid grid-cols-3 gap-2 sm:grid-cols-5 lg:grid-cols-9">
            {[
              ["scenes", graph.stats.scenes],
              ["beats", graph.stats.beats],
              ["intents", graph.stats.intents],
              ["characters", graph.stats.characters],
              ["locations", graph.stats.locations],
              ["emotions", countKind(graph, "emotion")],
              ["motifs", countKind(graph, "motif")],
              ["nodes", graph.stats.nodes],
              ["edges", graph.stats.edges],
            ].map(([k, v]) => (
              <div key={k as string} className="rounded-lg border border-zinc-800 bg-zinc-900/40 px-3 py-2">
                <div className="text-[9px] font-medium uppercase tracking-widest text-zinc-500">{k}</div>
                <div className="text-lg font-bold tabular-nums text-zinc-100">{v as number}</div>
              </div>
            ))}
          </div>

          <GraphView graph={graph} />

          <CharacterExplorer graph={graph} />
        </div>
      )}
    </div>
  );
}

function countKind(g: DirectorGraph, kind: string): number {
  return g.nodes.filter((n) => n.kind === kind).length;
}

/** "캐릭터를 누르면 등장 Scene · 감정 변화 · 관계 변화가 전부 나온다." */
function CharacterExplorer({ graph }: { graph: DirectorGraph }) {
  const [active, setActive] = useState<string | null>(null);
  const names = Object.keys(graph.characterIndex).sort(
    (a, b) => graph.characterIndex[b].lines - graph.characterIndex[a].lines
  );

  const info = active ? graph.characterIndex[active] : null;

  return (
    <Card className="px-5 py-5">
      <div className="mb-3 flex items-center gap-2">
        <h3 className="text-sm font-semibold text-zinc-100">캐릭터 익스플로러</h3>
        <span className="text-[10px] text-zinc-500">클릭 → 등장 Scene · 감정 · 샷 · 관계</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {names.map((n) => (
          <button
            key={n}
            onClick={() => setActive(active === n ? null : n)}
            className={`rounded-md px-2.5 py-1 text-xs font-medium transition ${
              active === n
                ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-emerald-500/30"
                : "bg-zinc-800/60 text-zinc-300 hover:bg-zinc-700/60"
            }`}
          >
            {n}
            <span className="ml-1 text-[10px] text-zinc-500">{graph.characterIndex[n].lines}</span>
          </button>
        ))}
      </div>

      {info && active && (
        <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <InfoBox title={`등장 Scene (${info.scenes.length})`} items={info.scenes} tone="sky" />
          <InfoBox title={`감정 (${info.emotions.length})`} items={info.emotions} tone="rose" />
          <InfoBox title={`관계 (${info.relations.length})`} items={info.relations.map((r) => `${r.kind} → ${r.target}`)} tone="violet" />
          <InfoBox title={`관련 Shot (${info.shots.length})`} items={info.shots} tone="amber" />
        </div>
      )}
    </Card>
  );
}

function InfoBox({ title, items, tone }: { title: string; items: string[]; tone: "sky" | "rose" | "violet" | "amber" }) {
  const toneCls = {
    sky: "text-sky-300",
    rose: "text-rose-300",
    violet: "text-violet-300",
    amber: "text-amber-300",
  }[tone];
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2.5">
      <div className="text-[10px] font-medium uppercase tracking-widest text-zinc-500">{title}</div>
      <div className="mt-1.5 flex flex-wrap gap-1">
        {items.length ? (
          items.map((it, i) => (
            <span key={i} className={`rounded bg-zinc-800/70 px-1.5 py-0.5 font-mono text-[10px] ${toneCls}`}>
              {it}
            </span>
          ))
        ) : (
          <span className="text-[10px] text-zinc-600">없음</span>
        )}
      </div>
    </div>
  );
}
