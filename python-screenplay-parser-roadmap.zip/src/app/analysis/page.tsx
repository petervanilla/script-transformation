"use client";

import { useState } from "react";
import type { SceneAnalysis } from "@/lib/analyzer/types";
import type { Scene as ParserScene } from "@/lib/parser/types";
import { ScenePicker, type SceneSelection } from "@/components/ScenePicker";
import { BeatCard } from "@/components/BeatCard";
import { Badge, Button, Card, EmptyState, SectionTitle, Spinner } from "@/components/ui";

export default function AnalysisPage() {
  const [sel, setSel] = useState<SceneSelection>({ movieSlug: "", sceneCode: "" });
  const [scene, setScene] = useState<ParserScene | null>(null);
  const [analysis, setAnalysis] = useState<SceneAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [useLlm, setUseLlm] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    if (!sel.movieSlug || !sel.sceneCode) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...sel, useLlm }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      setScene(data.scene);
      setAnalysis(data.analysis);
    } catch (e) {
      setError(e instanceof Error ? e.message : "분석 실패");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <SectionTitle
        sub="Phase 3·4 — 한 장면만 테스트. INT. STARBUCKS - 7:30 A.M. 부터 시작해 Scene 분리 · 인물 검출 · Action/Dialogue 분리 · Beat 경계 · 창작 금지(evidence)를 검증합니다."
        right={
          <div className="flex items-center gap-3">
            <label className="flex cursor-pointer items-center gap-2 text-[11px] text-zinc-400">
              <input
                type="checkbox"
                checked={useLlm}
                onChange={(e) => setUseLlm(e.target.checked)}
                className="h-3.5 w-3.5 accent-amber-500"
              />
              LLM 분석 (OPENAI_API_KEY 설정 시)
            </label>
            <Button disabled={loading || !sel.movieSlug} onClick={run}>
              {loading ? <Spinner label="분석 중…" /> : "Beat 분석 실행"}
            </Button>
          </div>
        }
      >
        Beat Analyzer
      </SectionTitle>

      <Card className="px-5 py-4">
        <ScenePicker value={sel} onChange={setSel} />
      </Card>

      {error && (
        <Card className="border-rose-500/30 px-4 py-3 text-xs text-rose-300">{error}</Card>
      )}

      {!analysis ? (
        <EmptyState>
          <div className="text-3xl">🔬</div>
          <div className="mt-1">장면을 선택하고 Beat 분석을 실행하세요</div>
          <div className="text-[11px] text-zinc-600">
            heuristic 엔진: 전환 · 화자 교체 · 긴 액션 문단에서 Beat 경계를 분할
          </div>
        </EmptyState>
      ) : (
        <div className="space-y-6">
          <Card className="px-5 py-4">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="violet">{analysis.sceneCode}</Badge>
              <span className="text-sm font-semibold text-zinc-100">{scene?.heading}</span>
              <div className="ml-auto flex gap-2">
                <Badge tone={analysis.source === "llm" ? "emerald" : "amber"}>
                  source: {analysis.source}
                </Badge>
                <Badge tone="zinc">{analysis.model}</Badge>
                <Badge tone="sky">{analysis.beats.length} beats</Badge>
              </div>
            </div>
            <div className="mt-2 text-xs text-zinc-400">
              <span className="text-zinc-600">scene_function · </span>
              {analysis.sceneFunction}
            </div>
          </Card>

          <div className="grid gap-3">
            {analysis.beats.map((b) => (
              <BeatCard key={b.index} beat={b} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
