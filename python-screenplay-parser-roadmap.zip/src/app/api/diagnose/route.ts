import { diagnoseFile } from "@/lib/diagnose";
import { DATA_FILE } from "@/lib/data";
import { loadMarkdown } from "@/lib/parser/markdown_loader";

export const dynamic = "force-dynamic";

/** Phase 1 — file state diagnosis (dataset_report.json) + raw preview. */
export async function GET() {
  try {
    const report = diagnoseFile(DATA_FILE);
    const { lines } = loadMarkdown(DATA_FILE);
    return Response.json({ ok: true, report, preview: lines.slice(0, 160) });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "diagnosis failed" },
      { status: 500 }
    );
  }
}
