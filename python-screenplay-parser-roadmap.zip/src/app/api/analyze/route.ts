import { DATA_FILE } from "@/lib/data";
import { parseScreenplayFile } from "@/lib/parser";
import { analyzeScene } from "@/lib/analyzer/beat_analyzer";
import { analyzeWithLLM } from "@/lib/analyzer/llm";
import { planShots } from "@/lib/analyzer/shot_planner";

export const dynamic = "force-dynamic";

/** Phase 3–4 — beat analysis for one scene (heuristic by default, LLM optional). */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as { movieSlug?: string; sceneCode?: string; useLlm?: boolean };
    const { movieSlug, sceneCode, useLlm = false } = body;
    if (!movieSlug || !sceneCode) {
      return Response.json({ ok: false, error: "movieSlug and sceneCode are required" }, { status: 400 });
    }

    const parsed = parseScreenplayFile(DATA_FILE);
    const movie = parsed.movies.find((m) => m.slug === movieSlug);
    const scene = movie?.scenes.find((s) => s.code === sceneCode);
    if (!scene) {
      return Response.json({ ok: false, error: `scene ${sceneCode} not found in ${movieSlug}` }, { status: 404 });
    }

    let analysis = analyzeScene(scene);

    if (useLlm && process.env.OPENAI_API_KEY) {
      try {
        const llm = await analyzeWithLLM(scene, process.env.OPENAI_API_KEY, process.env.OPENAI_MODEL);
        analysis = {
          ...analysis,
          sceneFunction: llm.sceneFunction || analysis.sceneFunction,
          source: "llm",
          model: llm.model,
          beats: llm.beats,
        };
      } catch (err) {
        // deterministic fallback — analysis stays heuristic
        analysis = {
          ...analysis,
          model: `llm-failed (${err instanceof Error ? err.message : "error"})`,
        };
      }
    }

    analysis.shots = planShots(analysis.beats, scene.code);
    return Response.json({ ok: true, scene, analysis });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "analysis failed" },
      { status: 500 }
    );
  }
}
