import { db } from "@/db";
import { movies, scenes } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { DATA_FILE } from "@/lib/data";
import { parseScreenplayFile } from "@/lib/parser";

export const dynamic = "force-dynamic";

/** GET — parse only (no DB write). Used by scene pickers. */
export async function GET() {
  try {
    const parsed = parseScreenplayFile(DATA_FILE);
    return Response.json({ ok: true, parsed });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "parse failed" },
      { status: 500 }
    );
  }
}

/** Phase 2 — parse the raw source and upsert movies+scenes into PostgreSQL. */
export async function POST() {
  try {
    const parsed = parseScreenplayFile(DATA_FILE);

    for (const movie of parsed.movies) {
      const [existingMovie] = await db.select().from(movies).where(eq(movies.slug, movie.slug));
      let movieId: string;
      if (existingMovie) {
        await db
          .update(movies)
          .set({ title: movie.title, sceneCount: movie.scenes.length, updatedAt: new Date() })
          .where(eq(movies.id, existingMovie.id));
        movieId = existingMovie.id;
      } else {
        const [inserted] = await db
          .insert(movies)
          .values({
            title: movie.title,
            slug: movie.slug,
            sourceFile: "data/movies.md",
            sceneCount: movie.scenes.length,
          })
          .returning();
        movieId = inserted.id;
      }

      // Upsert scenes by stable code (preserves saved beat reviews on re-parse)
      for (const sc of movie.scenes) {
        const values = {
          sceneIndex: sc.index,
          code: sc.code,
          heading: sc.heading,
          location: sc.location,
          interior: sc.interior,
          timeOfDay: sc.timeOfDay,
          startLine: sc.startLine,
          endLine: sc.endLine,
          rawText: sc.rawText,
          elements: sc.elements,
        };
        const [existingScene] = await db
          .select()
          .from(scenes)
          .where(and(eq(scenes.movieId, movieId), eq(scenes.code, sc.code)));
        if (existingScene) {
          await db.update(scenes).set(values).where(eq(scenes.id, existingScene.id));
        } else {
          await db.insert(scenes).values({ movieId, ...values });
        }
      }
    }

    return Response.json({ ok: true, parsed });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "parse failed" },
      { status: 500 }
    );
  }
}
