import { db } from "@/db";
import { graphMovies, sources } from "@/db/schema";
import { eq } from "drizzle-orm";
import { DATA_FILE } from "@/lib/data";
import { loadMarkdown } from "@/lib/parser/markdown_loader";
import { parseScreenplay } from "@/lib/parser";
import { buildDirectorGraph } from "@/lib/dkg";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** GET /api/graph?sourceId=&movieSlug=&sample=1 — Director Knowledge Graph.

 * With ?sample=1 the graph is built in-memory from the built-in dataset
 * (data/movies.md) so the page is demonstrable without an upload.
 */
export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const sourceId = searchParams.get("sourceId");
    const movieSlug = searchParams.get("movieSlug");
    const sample = searchParams.get("sample") === "1";

    if (sample) {
      const { raw, lines } = loadMarkdown(DATA_FILE);
      const parsed = parseScreenplay(raw, lines);
      const graphs = parsed.movies.map((m) => buildDirectorGraph(m));
      const target = movieSlug ? graphs.find((g) => g.movieSlug === movieSlug) : graphs[0];
      return Response.json({
        ok: true,
        source: null,
        sample: true,
        movies: graphs.map((g) => ({ slug: g.movieSlug, title: g.movieTitle })),
        graph: target,
      });
    }

    const query = sourceId
      ? db.select().from(graphMovies).where(eq(graphMovies.sourceId, sourceId))
      : db.select().from(graphMovies);
    const graphs = await query;
    if (!graphs.length) {
      return Response.json({ ok: false, error: "no graphs found — upload a screenplay first" }, { status: 404 });
    }
    const target = movieSlug ? graphs.find((g) => g.slug === movieSlug) : graphs[0];
    if (!target) return Response.json({ ok: false, error: "movie not found" }, { status: 404 });

    const [source] = sourceId
      ? await db.select().from(sources).where(eq(sources.id, sourceId))
      : [null];

    return Response.json({
      ok: true,
      source: source ?? null,
      movies: graphs.map((g) => ({ slug: g.slug, title: g.title })),
      graph: target.graph,
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "그래프 조회 실패" },
      { status: 500 }
    );
  }
}
