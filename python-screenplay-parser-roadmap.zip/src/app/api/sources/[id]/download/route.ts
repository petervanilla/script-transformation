import { db } from "@/db";
import { sources, graphMovies } from "@/db/schema";
import { eq } from "drizzle-orm";
import * as fs from "fs";
import * as path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "data", "uploads");

/** GET /api/sources/:id/download?type=original|text|json|graph&movie=slug

 * original → the uploaded file as-is
 * text     → extracted plain screenplay text (.txt)
 * json     → parsed screenplay JSON (Scene/Beat structure)
 * graph    → Director Knowledge Graph JSON for one movie (movie=slug)
 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const url = new URL(req.url);
    const type = (url.searchParams.get("type") ?? "original") as string;
    const movieSlug = url.searchParams.get("movie");

    const [row] = await db.select().from(sources).where(eq(sources.id, id));
    if (!row) return Response.json({ ok: false, error: "source not found" }, { status: 404 });

    if (type === "original") {
      const data = fs.readFileSync(path.join(UPLOAD_DIR, row.filename));
      return new Response(new Uint8Array(data), {
        headers: {
          "Content-Type": row.mime ?? "application/octet-stream",
          "Content-Disposition": `attachment; filename="${encodeURIComponent(row.originalName)}"`,
        },
      });
    }

    if (type === "text") {
      const data = fs.readFileSync(path.join(UPLOAD_DIR, `${row.id}.txt`), "utf-8");
      return new Response(data, {
        headers: {
          "Content-Type": "text/plain; charset=utf-8",
          "Content-Disposition": `attachment; filename="${row.originalName}.txt"`,
        },
      });
    }

    if (type === "json" || type === "graph") {
      const graphs = await db.select().from(graphMovies).where(eq(graphMovies.sourceId, id));
      if (!graphs.length)
        return Response.json({ ok: false, error: "no graphs for this source" }, { status: 404 });

      if (type === "graph") {
        const g = movieSlug ? graphs.find((x) => x.slug === movieSlug) : graphs[0];
        if (!g) return Response.json({ ok: false, error: "movie not found" }, { status: 404 });
        const payload = JSON.stringify(g.graph, null, 2);
        return new Response(payload, {
          headers: {
            "Content-Type": "application/json; charset=utf-8",
            "Content-Disposition": `attachment; filename="${g.slug}.dkg.json"`,
          },
        });
      }

      // json: parsed screenplay re-derived from stored text
      const text = fs.readFileSync(path.join(UPLOAD_DIR, `${row.id}.txt`), "utf-8");
      const { parseScreenplay } = await import("@/lib/parser");
      const parsed = parseScreenplay(text, text.split("\n"));
      const payload = JSON.stringify(parsed, null, 2);
      return new Response(payload, {
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename="${row.originalName}.parsed.json"`,
        },
      });
    }

    return Response.json({ ok: false, error: "unknown type" }, { status: 400 });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "다운로드 실패" },
      { status: 500 }
    );
  }
}
