import { db } from "@/db";
import { sources, graphMovies } from "@/db/schema";
import { eq } from "drizzle-orm";
import * as fs from "fs";
import * as path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const UPLOAD_DIR = path.join(process.cwd(), "data", "uploads");

/** DELETE /api/sources?id=... — remove source + graphs + uploaded files. */
export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ ok: false, error: "id required" }, { status: 400 });

    const [row] = await db.select().from(sources).where(eq(sources.id, id));
    if (row?.filename) {
      const f1 = path.join(UPLOAD_DIR, row.filename);
      const f2 = path.join(UPLOAD_DIR, `${row.id}.txt`);
      [f1, f2].forEach((f) => {
        try {
          fs.unlinkSync(f);
        } catch {
          /* ignore */
        }
      });
    }
    await db.delete(graphMovies).where(eq(graphMovies.sourceId, id));
    await db.delete(sources).where(eq(sources.id, id));
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "삭제 실패" },
      { status: 500 }
    );
  }
}
