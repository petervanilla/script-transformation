import { db } from "@/db";
import { beats, movies, scenes, shots } from "@/db/schema";
import { and, asc, eq, inArray } from "drizzle-orm";
import type { Beat, ShotPlan } from "@/lib/analyzer/types";

export const dynamic = "force-dynamic";

export interface ReviewBeat extends Beat {
  id?: string;
  status?: string;
  notes?: string;
  shots?: ShotPlan[];
}

/** GET /api/review?movieSlug=&sceneCode= — saved review state for a scene. */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const movieSlug = searchParams.get("movieSlug");
  const sceneCode = searchParams.get("sceneCode");
  if (!movieSlug || !sceneCode) {
    return Response.json({ ok: false, error: "movieSlug and sceneCode required" }, { status: 400 });
  }

  try {
    const [movie] = await db.select().from(movies).where(eq(movies.slug, movieSlug));
    if (!movie) return Response.json({ ok: true, scene: null, beats: [], saved: false });
    const [scene] = await db
      .select()
      .from(scenes)
      .where(and(eq(scenes.movieId, movie.id), eq(scenes.code, sceneCode)));
    if (!scene) return Response.json({ ok: true, scene: null, beats: [], saved: false });

    const savedBeats = await db
      .select()
      .from(beats)
      .where(eq(beats.sceneId, scene.id))
      .orderBy(asc(beats.beatIndex));
    const beatIds = savedBeats.map((b) => b.id);
    const savedShots = beatIds.length
      ? await db.select().from(shots).where(inArray(shots.beatId, beatIds))
      : [];

    return Response.json({
      ok: true,
      scene,
      saved: savedBeats.length > 0,
      beats: savedBeats.map((b) => ({
        id: b.id,
        index: b.beatIndex,
        startText: b.startText ?? "",
        endText: b.endText ?? "",
        speakers: (b.speakers as string[]) ?? [],
        objective: b.objective ?? "",
        action: b.action ?? "",
        emotionBefore: b.emotionBefore ?? "중립",
        emotionAfter: b.emotionAfter ?? "중립",
        conflict: b.conflict,
        relationshipChange: b.relationshipChange ?? "",
        evidence: (b.evidence as string[]) ?? [],
        confidence: b.confidence ?? 0,
        status: b.status ?? "pending",
        notes: b.notes ?? "",
        shots: savedShots.filter((s) => s.beatId === b.id),
      })),
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "load failed" },
      { status: 500 }
    );
  }
}

/** POST /api/review — save (or approve) beats + shot plans for a scene. */
export async function POST(req: Request) {
  try {
    const body = (await req.json()) as {
      movieSlug?: string;
      sceneCode?: string;
      status?: string;
      beats?: ReviewBeat[];
    };
    const { movieSlug, sceneCode, status = "pending", beats: incoming = [] } = body;
    if (!movieSlug || !sceneCode) {
      return Response.json({ ok: false, error: "movieSlug and sceneCode required" }, { status: 400 });
    }

    const [movie] = await db.select().from(movies).where(eq(movies.slug, movieSlug));
    if (!movie) return Response.json({ ok: false, error: "movie not found" }, { status: 404 });
    const [scene] = await db
      .select()
      .from(scenes)
      .where(and(eq(scenes.movieId, movie.id), eq(scenes.code, sceneCode)));
    if (!scene) return Response.json({ ok: false, error: "scene not found" }, { status: 404 });

    // Replace strategy: delete previous beats (cascades shots) then insert.
    await db.delete(beats).where(eq(beats.sceneId, scene.id));

    for (const beat of incoming) {
      const [saved] = await db
        .insert(beats)
        .values({
          sceneId: scene.id,
          beatIndex: beat.index,
          startText: beat.startText,
          endText: beat.endText,
          speakers: beat.speakers,
          objective: beat.objective,
          action: beat.action,
          emotionBefore: beat.emotionBefore,
          emotionAfter: beat.emotionAfter,
          conflict: beat.conflict,
          relationshipChange: beat.relationshipChange,
          evidence: beat.evidence,
          confidence: beat.confidence,
          analysisSource: "heuristic",
          status,
          notes: beat.notes ?? "",
          updatedAt: new Date(),
        })
        .returning();

      for (const shot of beat.shots ?? []) {
        await db.insert(shots).values({
          beatId: saved.id,
          shotCode: shot.shotCode,
          intent: shot.intent,
          subject: shot.subject,
          shotSize: shot.shotSize,
          camera: shot.camera,
          motion: shot.motion,
          prompt: shot.prompt,
        });
      }
    }

    return Response.json({ ok: true, saved: incoming.length });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "save failed" },
      { status: 500 }
    );
  }
}
