import { db } from "@/db";
import { sources, graphMovies } from "@/db/schema";
import { desc } from "drizzle-orm";
import * as fs from "fs";
import * as path from "path";
import { randomUUID } from "crypto";
import { extractScreenplay, detectFormat } from "@/lib/formats";
import { parseScreenplay } from "@/lib/parser";
import { buildDirectorGraph } from "@/lib/dkg";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 60;

const UPLOAD_DIR = path.join(process.cwd(), "data", "uploads");

/** POST multipart/form-data (field "file") → extract, parse, build DKG, store. */
export async function POST(req: Request) {
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File)) {
      return Response.json({ ok: false, error: "파일이 없습니다 (field: file)" }, { status: 400 });
    }
    const format = detectFormat(file.name);
    if (!format) {
      return Response.json(
        { ok: false, error: `지원 형식 아님: ${file.name} (txt/md/json/pdf/docx)` },
        { status: 400 }
      );
    }

    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    const id = randomUUID();
    const buf = Buffer.from(await file.arrayBuffer());

    // preserve original + extracted text
    const safeName = `${id}-${file.name.replace(/[^\w.\-]+/g, "_")}`;
    fs.writeFileSync(path.join(UPLOAD_DIR, safeName), buf);

    // 1. extract plain screenplay text
    const extracted = await extractScreenplay(file.name, buf);
    const textPath = path.join(UPLOAD_DIR, `${id}.txt`);
    fs.writeFileSync(textPath, extracted.text, "utf-8");

    // 2. parse
    const lines = extracted.text.split("\n");
    const parsed = parseScreenplay(extracted.text, lines);

    // 3. build DKG for each movie
    const graphs = parsed.movies.map((m) => buildDirectorGraph(m));

    // 4. store metadata + graphs
    const [sourceRow] = await db
      .insert(sources)
      .values({
        id,
        filename: safeName,
        originalName: file.name,
        format,
        sizeBytes: buf.length,
        mime: file.type || "application/octet-stream",
        title: extracted.title || parsed.movies[0]?.title,
        charCount: extracted.text.length,
        movieCount: parsed.movies.length,
        sceneCount: parsed.totalScenes,
        status: "parsed",
      })
      .returning();

    for (const g of graphs) {
      await db.insert(graphMovies).values({
        sourceId: id,
        title: g.movieTitle,
        slug: g.movieSlug,
        graph: g,
      });
    }

    return Response.json({
      ok: true,
      source: sourceRow,
      movies: graphs.map((g) => ({
        title: g.movieTitle,
        slug: g.movieSlug,
        stats: g.stats,
      })),
    });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "업로드 실패" },
      { status: 500 }
    );
  }
}

/** GET — list all uploaded sources. */
export async function GET() {
  try {
    const rows = await db
      .select()
      .from(sources)
      .orderBy(desc(sources.createdAt));
    return Response.json({ ok: true, sources: rows });
  } catch (err) {
    return Response.json(
      { ok: false, error: err instanceof Error ? err.message : "조회 실패" },
      { status: 500 }
    );
  }
}
