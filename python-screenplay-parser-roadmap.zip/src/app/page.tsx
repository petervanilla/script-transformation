"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { DatasetReport } from "@/lib/parser/types";
import { Badge, Card, SectionTitle, Spinner, Stat } from "@/components/ui";

const PIPELINE = [
  { key: "raw", label: "Upload", sub: "JSON·Word·txt·PDF", emoji: "📂" },
  { key: "parser", label: "Screenplay Parser", sub: "텍스트 추출 → Scene", emoji: "⚙️" },
  { key: "scene", label: "Scene / Beat", sub: "Action·Dialogue 분리", emoji: "🧩" },
  { key: "beat", label: "Director Reasoning", sub: "Intent + 9차원 연출", emoji: "🧠" },
  { key: "review", label: "검수", sub: "승인·수정·재분석", emoji: "✅" },
  { key: "graph", label: "Knowledge Graph", sub: "관계로 저장하는 DKG", emoji: "🕸️" },
];

const PHASES = [
  {
    href: "/upload",
    n: "NEW",
    title: "파일 업로드 · 다운로드",
    desc: "JSON·Word·txt·PDF·Markdown 를 끌어다 놓으면 텍스트 추출 → 파싱 → Director Knowledge Graph 자동 생성. 원본/TXT/파싱JSON/DKG JSON 다운로드.",
  },
  {
    href: "/graph",
    n: "DKG",
    title: "Director Knowledge Graph",
    desc: "Movie→Sequence→Scene→Beat→Intent→{감정·카메라·블로킹·조명·구도·편집·음악·프롬프트·모션}. 캐릭터 클릭으로 등장 씬·감정·관계를 한 번에.",
  },
  {
    href: "/diagnose",
    n: "Phase 1",
    title: "파일 상태 진단",
    desc: "movies.md의 인코딩·구분자·헤딩 일관성·깨진 문자를 검사해 dataset_report.json을 생성합니다.",
  },
  {
    href: "/parser",
    n: "Phase 2",
    title: "Screenplay Parser",
    desc: "영화 → Scene → Action/Dialogue/Transition 분리. 카메라나 감정은 만들지 않습니다.",
  },
  {
    href: "/analysis",
    n: "Phase 3·4",
    title: "Beat 분석 (한 장면 테스트)",
    desc: "INT. STARBUCKS - 7:30 A.M. 부터 시작. evidence(원문 근거)와 confidence로 판단을 검증합니다.",
  },
  {
    href: "/review",
    n: "Phase 6",
    title: "검수 시스템",
    desc: "원문 | 구조화 결과 | Shot 후보. 승인 · 수정 · 재분석 · 저장을 PostgreSQL에 기록합니다.",
  },
];

export default function Dashboard() {
  const [report, setReport] = useState<DatasetReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/diagnose")
      .then((r) => r.json())
      .then((d) => setReport(d.report ?? null))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-10">
      {/* Hero */}
      <section className="fade-up relative overflow-hidden rounded-2xl border border-zinc-800 bg-gradient-to-br from-zinc-900 via-zinc-950 to-amber-950/40 px-6 py-12 sm:px-10">
        <div className="pointer-events-none absolute -right-20 -top-24 h-72 w-72 rounded-full bg-amber-500/10 blur-3xl" />
        <div className="relative">
          <Badge tone="amber">공용 Director Dataset 파이프라인</Badge>
          <h1 className="mt-4 max-w-2xl text-3xl font-bold leading-tight tracking-tight text-zinc-50 sm:text-4xl">
            Python Screenplay Converter
          </h1>
          <p className="mt-3 max-w-2xl text-sm leading-relaxed text-zinc-400">
            movies.md를 새로 쓰지 않고 Raw Source로 보존합니다. 그 위에 객관적인 시나리오 요소를
            추출하고, Beat와 연출 의도를 구조화해 <span className="text-amber-300">O!SHOT · Motion
            Director 공용 데이터셋</span>으로 발전시킵니다.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Link
              href="/upload"
              className="rounded-lg bg-amber-500 px-4 py-2 text-xs font-semibold text-zinc-950 transition hover:bg-amber-400"
            >
              📂 대본 업로드하기 →
            </Link>
            <Link
              href="/graph"
              className="rounded-lg border border-zinc-700 px-4 py-2 text-xs font-semibold text-zinc-300 transition hover:border-zinc-500"
            >
              🕸️ 지식 그래프 보기
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <Stat label="movies" value={loading ? "…" : (report?.movies ?? "-")} tone="amber" hint="구분자 ***" />
          <Stat label="scenes" value={loading ? "…" : (report?.scenesDetected ?? "-")} tone="sky" hint="감지된 씬" />
          <Stat label="encoding" value={loading ? "…" : (report?.encoding ?? "-")} hint="BOM 검사" />
          <Stat
            label="line endings"
            value={loading ? "…" : (report?.lineEndings ?? "-")}
            tone={report?.lineEndings === "LF" ? "emerald" : "rose"}
            hint="CRLF/LF"
          />
          <Stat
            label="character cues"
            value={loading ? "…" : (report?.characterCues ?? "-")}
            hint="인물 검출"
          />
          <Stat
            label="risks"
            value={loading ? "…" : (report?.parsingRisks.length ?? "-")}
            tone={(report?.parsingRisks.length ?? 0) > 0 ? "rose" : "emerald"}
            hint="파싱 리스크"
          />
        </div>
      </section>

      {/* Pipeline */}
      <section>
        <h2 className="mb-4 text-base font-semibold text-zinc-100">파이프라인</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {PIPELINE.map((p, i) => (
            <Card key={p.key} className="relative px-4 py-4">
              <div className="text-[10px] font-medium uppercase tracking-widest text-zinc-600">
                step {i + 1}
              </div>
              <div className="mt-1.5 text-xl">{p.emoji}</div>
              <div className="mt-1.5 text-sm font-semibold text-zinc-100">{p.label}</div>
              <div className="mt-0.5 text-[11px] leading-snug text-zinc-500">{p.sub}</div>
            </Card>
          ))}
        </div>
      </section>

      {/* Phases */}
      <section>
        <h2 className="mb-4 text-base font-semibold text-zinc-100">단계별 구현</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {PHASES.map((p) => (
            <Link key={p.href} href={p.href}>
              <Card className="group h-full px-5 py-5 transition hover:border-amber-500/40 hover:bg-zinc-900">
                <div className="flex items-center gap-2">
                  <Badge tone="violet">{p.n}</Badge>
                  <span className="text-sm font-semibold text-zinc-100 group-hover:text-amber-300">
                    {p.title}
                  </span>
                </div>
                <p className="mt-2 text-xs leading-relaxed text-zinc-500">{p.desc}</p>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      {/* DKG architecture */}
      <section>
        <SectionTitle sub="하나의 대본에서 스토리보드·이미지 프롬프트·비디오 프롬프트·모션 JSON·감독 의도 분석까지 같은 그래프에서 파생">
          Director Knowledge Graph 구조
        </SectionTitle>
        <Card className="overflow-x-auto px-6 py-6">
          <div className="flex min-w-max items-start gap-3 font-mono text-xs">
            {[
              { k: "Movie", c: "#f59e0b" },
              { k: "Sequence", c: "#d97706" },
              { k: "Scene", c: "#38bdf8" },
              { k: "Beat", c: "#a78bfa" },
              { k: "Intent", c: "#f472b6" },
            ].map((n, i) => (
              <div key={n.k} className="flex items-center gap-3">
                <div
                  className="rounded-lg px-3 py-2 font-semibold text-zinc-950"
                  style={{ background: n.c }}
                >
                  {n.k}
                </div>
                {i < 4 && <span className="text-zinc-600">→</span>}
              </div>
            ))}
            <span className="px-1 pt-2 text-zinc-600">├─</span>
            <div className="flex flex-col gap-1.5">
              {["Emotion", "Camera", "Blocking", "Performance", "Lighting", "Composition", "Editing", "Music", "Prompt", "Motion JSON"].map(
                (d, i) => (
                  <span
                    key={d}
                    className="rounded-md bg-zinc-800/80 px-2.5 py-1 text-zinc-300"
                  >
                    {i === 9 ? "└─ " : "├─ "}
                    {d}
                  </span>
                )
              )}
            </div>
          </div>
        </Card>
      </section>

      {/* Discipline callout */}
      <section className="grid gap-4 lg:grid-cols-2">
        <Card className="border-rose-500/20 bg-rose-950/10 px-5 py-5">
          <h3 className="text-sm font-semibold text-rose-300">❌ 하지 말아야 할 방식</h3>
          <p className="mt-2 rounded-lg border border-rose-500/20 bg-rose-950/20 px-3 py-2 font-mono text-[11px] leading-relaxed text-rose-200/80">
            “이 시나리오 전체를 분석해서 카메라와 감정을 JSON으로 만들어줘.”
          </p>
          <ul className="mt-3 grid grid-cols-2 gap-1.5 text-[11px] text-zinc-400">
            {["긴 문맥이 잘린다", "장면 누락", "AI의 카메라 창작", "재실행 결과 불일치", "인물 관계 흔들림", "원문·해석 경계 소실"].map((x) => (
              <li key={x} className="flex items-center gap-1.5">
                <span className="text-rose-400">✕</span> {x}
              </li>
            ))}
          </ul>
        </Card>
        <Card className="border-emerald-500/20 bg-emerald-950/10 px-5 py-5">
          <h3 className="text-sm font-semibold text-emerald-300">✓ 작업 단위 제한</h3>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            {["Movie", "Scene", "Beat", "Shot"].map((s, i) => (
              <span key={s} className="flex items-center gap-2">
                <span className="rounded-md bg-emerald-500/10 px-2.5 py-1 font-mono text-[11px] font-semibold text-emerald-300 ring-1 ring-emerald-500/30">
                  {s}
                </span>
                {i < 3 && <span className="text-zinc-600">→</span>}
              </span>
            ))}
          </div>
          <ul className="mt-3 grid grid-cols-2 gap-1.5 text-[11px] text-zinc-400">
            {["각 단계 결과를 저장 후 다음 단계로", "원문 근거(evidence) 필수", "신뢰도(confidence) 기록", "단계별 재실행 가능"].map((x) => (
              <li key={x} className="flex items-center gap-1.5">
                <span className="text-emerald-400">✓</span> {x}
              </li>
            ))}
          </ul>
        </Card>
      </section>

      <section className="text-center text-[11px] text-zinc-600">
        Python 참조 구현: <span className="font-mono text-zinc-500">python/screenplay_parser</span> ·
        웹앱 동일 로직: <span className="font-mono text-zinc-500">src/lib/parser</span>
      </section>
    </div>
  );
}
