"use client";

import { useCallback, useEffect, useState } from "react";
import type { SceneAnalysis, ShotPlan } from "@/lib/analyzer/types";
import type { Scene as ParserScene } from "@/lib/parser/types";
import { ScenePicker, type SceneSelection } from "@/components/ScenePicker";
import { ConfidenceBar } from "@/components/BeatCard";
import { Badge, Button, Card, EmptyState, SectionTitle, Spinner } from "@/components/ui";

interface EditableBeat {
  index: number;
  startText: string;
  endText: string;
  speakers: string[];
  objective: string;
  action: string;
  emotionBefore: string;
  emotionAfter: string;
  conflict: string | null;
  relationshipChange: string;
  evidence: string[];
  confidence: number;
  status?: string;
  notes?: string;
}

export default function ReviewPage() {
  const [sel, setSel] = useState<SceneSelection>({ movieSlug: "", sceneCode: "" });
  const [scene, setScene] = useState<ParserScene | null>(null);
  const [beats, setBeats] = useState<EditableBeat[]>([]);
  const [shotsByBeat, setShotsByBeat] = useState<Record<number, ShotPlan[]>>({});
  const [sceneFunction, setSceneFunction] = useState("");
  const [source, setSource] = useState<"heuristic" | "llm">("heuristic");
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const applyAnalysis = (analysis: SceneAnalysis, sc: ParserScene) => {
    setScene(sc);
    setSceneFunction(analysis.sceneFunction);
    setSource(analysis.source);
    setBeats(analysis.beats.map((b) => ({ ...b, status: "pending" })));
    const grouped: Record<number, ShotPlan[]> = {};
    analysis.shots.forEach((s, i) => {
      const beatIdx = i + 1;
      grouped[beatIdx] = [...(grouped[beatIdx] ?? []), s];
    });
    setShotsByBeat(grouped);
  };

  const load = useCallback(
    async (s: SceneSelection) => {
      if (!s.movieSlug || !s.sceneCode) return;
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/review?movieSlug=${s.movieSlug}&sceneCode=${s.sceneCode}`);
        const data = await res.json();
        if (!data.ok) throw new Error(data.error);

        if (data.saved && data.beats.length) {
          setScene(data.scene);
          setBeats(data.beats);
          const grouped: Record<number, ShotPlan[]> = {};
          data.beats.forEach((b: EditableBeat & { shots?: ShotPlan[] }) => {
            if (b.shots?.length) grouped[b.index] = b.shots;
          });
          setShotsByBeat(grouped);
          showToast("저장된 검수 상태를 불러왔습니다");
        } else {
          // no saved state → fresh heuristic analysis
          const aRes = await fetch("/api/analyze", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(s),
          });
          const aData = await aRes.json();
          if (!aData.ok) throw new Error(aData.error);
          applyAnalysis(aData.analysis, aData.scene);
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "로드 실패");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  useEffect(() => {
    if (sel.movieSlug && sel.sceneCode) load(sel);
  }, [sel, load]);

  const updateBeat = (index: number, field: keyof EditableBeat, value: string) => {
    setBeats((prev) =>
      prev.map((b) => (b.index === index ? { ...b, [field]: value } : b))
    );
  };

  const reanalyze = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sel),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      applyAnalysis(data.analysis, data.scene);
      showToast("재분석 완료 (heuristic)");
    } catch (e) {
      setError(e instanceof Error ? e.message : "재분석 실패");
    } finally {
      setLoading(false);
    }
  };

  const save = async (status: "approved" | "revised") => {
    setSaving(true);
    setError(null);
    try {
      const payload = beats.map((b) => ({
        ...b,
        status,
        shots: shotsByBeat[b.index] ?? [],
      }));
      const res = await fetch("/api/review", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...sel, status, beats: payload }),
      });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      setBeats((prev) => prev.map((b) => ({ ...b, status })));
      showToast(status === "approved" ? "✓ 승인 저장 완료" : "✓ 수정본 저장 완료");
    } catch (e) {
      setError(e instanceof Error ? e.message : "저장 실패");
    } finally {
      setSaving(false);
    }
  };

  const statusTone = (s?: string) =>
    s === "approved" ? "emerald" : s === "revised" ? "amber" : "zinc";

  return (
    <div className="space-y-6">
      <SectionTitle
        sub="Phase 6 — 원문 Scene | 구조화 결과(Scene/Beat/인물/감정/의도) | Shot 후보 | 승인 · 수정 · 재분석 · 저장"
        right={
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="outline" disabled={loading || !beats.length} onClick={reanalyze}>
              {loading ? <Spinner label="분석 중…" /> : "↻ 재분석"}
            </Button>
            <Button variant="success" disabled={saving || !beats.length} onClick={() => save("approved")}>
              ✓ 승인
            </Button>
            <Button disabled={saving || !beats.length} onClick={() => save("revised")}>
              💾 저장
            </Button>
          </div>
        }
      >
        검수 시스템
      </SectionTitle>

      <Card className="px-5 py-4">
        <ScenePicker value={sel} onChange={setSel} />
      </Card>

      {toast && (
        <div className="fixed bottom-6 right-6 z-50 rounded-lg border border-emerald-500/30 bg-zinc-900 px-4 py-2.5 text-xs font-medium text-emerald-300 shadow-xl fade-up">
          {toast}
        </div>
      )}
      {error && (
        <Card className="border-rose-500/30 px-4 py-3 text-xs text-rose-300">{error}</Card>
      )}

      {!scene ? (
        <EmptyState>
          <div className="text-3xl">✅</div>
          <div className="mt-1">영화와 Scene을 선택하면 원문 · 구조화 결과 · Shot 후보가 표시됩니다</div>
        </EmptyState>
      ) : (
        <div className="space-y-4">
          {/* Scene header */}
          <Card className="px-5 py-3.5">
            <div className="flex flex-wrap items-center gap-2">
              <Badge tone="violet">{scene.code}</Badge>
              <span className="text-sm font-semibold text-zinc-100">{scene.heading}</span>
              <div className="ml-auto flex flex-wrap gap-2">
                <Badge tone="sky">{beats.length} beats</Badge>
                <Badge tone={source === "llm" ? "emerald" : "amber"}>source: {source}</Badge>
                <Badge tone="zinc">{sceneFunction}</Badge>
              </div>
            </div>
          </Card>

          {/* two-column: original | structured */}
          <div className="grid gap-4 lg:grid-cols-2">
            {/* 원문 Scene */}
            <Card className="flex flex-col overflow-hidden">
              <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900/60 px-4 py-2.5">
                <span className="text-[11px] font-semibold uppercase tracking-widest text-zinc-400">
                  원문 Scene
                </span>
                <span className="text-[10px] text-zinc-600">L{scene.startLine}–{scene.endLine}</span>
              </div>
              <pre className="max-h-[560px] flex-1 overflow-auto whitespace-pre-wrap px-4 py-3 font-mono text-[11.5px] leading-relaxed text-zinc-300">
                {scene.rawText}
              </pre>
            </Card>

            {/* 구조화 결과 */}
            <div className="space-y-3">
              {beats.map((b) => (
                <Card key={b.index} className="px-4 py-3.5">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-mono text-[11px] font-bold text-amber-400">
                      BEAT {String(b.index).padStart(2, "0")}
                    </span>
                    {b.speakers.map((s) => (
                      <Badge key={s} tone="sky">{s}</Badge>
                    ))}
                    <div className="ml-auto flex items-center gap-2">
                      <Badge tone={statusTone(b.status) as "emerald" | "amber" | "zinc"}>
                        {b.status ?? "pending"}
                      </Badge>
                      <ConfidenceBar value={b.confidence} />
                    </div>
                  </div>
                  <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
                    <EditField label="목표 objective" value={b.objective} onChange={(v) => updateBeat(b.index, "objective", v)} />
                    <EditField label="행동 action" value={b.action} onChange={(v) => updateBeat(b.index, "action", v)} />
                    <EditField label="감정 before" value={b.emotionBefore} onChange={(v) => updateBeat(b.index, "emotionBefore", v)} />
                    <EditField label="감정 after" value={b.emotionAfter} onChange={(v) => updateBeat(b.index, "emotionAfter", v)} />
                    <EditField label="갈등 conflict" value={b.conflict ?? ""} onChange={(v) => updateBeat(b.index, "conflict", v)} />
                    <EditField label="관계 변화" value={b.relationshipChange} onChange={(v) => updateBeat(b.index, "relationshipChange", v)} />
                    <div className="sm:col-span-2">
                      <EditField label="검수 노트 notes" value={b.notes ?? ""} onChange={(v) => updateBeat(b.index, "notes", v)} />
                    </div>
                  </div>
                  <div className="mt-2.5 flex flex-wrap gap-1.5">
                    {b.evidence.slice(0, 3).map((e, i) => (
                      <span key={i} className="rounded bg-amber-500/5 px-1.5 py-0.5 font-mono text-[9.5px] text-amber-200/70 ring-1 ring-amber-500/10">
                        “{e.length > 60 ? e.slice(0, 60) + "…" : e}”
                      </span>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </div>

          {/* Shot 후보 */}
          <Card className="overflow-hidden">
            <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900/60 px-4 py-2.5">
              <span className="text-[11px] font-semibold uppercase tracking-widest text-zinc-400">
                Shot 후보 (Phase 7 미리보기)
              </span>
              <span className="text-[10px] text-zinc-600">
                Beat → Shot Plan → Camera/Motion → Video Prompt
              </span>
            </div>
            <div className="grid gap-3 p-4 sm:grid-cols-2 xl:grid-cols-3">
              {beats.flatMap((b) =>
                (shotsByBeat[b.index] ?? []).map((s) => (
                  <div key={s.shotCode} className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[10px] font-bold text-sky-300">{s.shotCode}</span>
                      <Badge tone="zinc">{s.shotSize}</Badge>
                    </div>
                    <div className="mt-2 text-xs font-medium text-zinc-100">🎯 {s.intent}</div>
                    <div className="mt-1 text-[11px] text-zinc-400">
                      subject: <span className="text-zinc-300">{s.subject}</span>
                    </div>
                    <div className="mt-1.5 grid grid-cols-3 gap-1 text-[10px] text-zinc-500">
                      <div>📷 {s.camera.movement}</div>
                      <div>🔭 {s.camera.lens}</div>
                      <div>📐 {s.camera.height}</div>
                    </div>
                    <div className="mt-1.5 text-[10px] text-zinc-500">
                      🎭 {s.motion.actorAction} · tempo: {s.motion.tempo}
                    </div>
                    <div className="mt-2 rounded bg-zinc-900 px-2 py-1.5 font-mono text-[9.5px] leading-snug text-zinc-500">
                      {s.prompt}
                    </div>
                  </div>
                ))
              )}
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

function EditField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="block">
      <span className="text-[9px] font-medium uppercase tracking-widest text-zinc-600">{label}</span>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={2}
        className="mt-1 w-full resize-y rounded-lg border border-zinc-800 bg-zinc-950/60 px-2.5 py-1.5 text-xs leading-relaxed text-zinc-200 outline-none transition focus:border-amber-500/50"
      />
    </label>
  );
}
