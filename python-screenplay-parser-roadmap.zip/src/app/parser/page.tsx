"use client";

import { useState } from "react";
import type { Movie, ParsedScreenplay } from "@/lib/parser/types";
import { Badge, Button, Card, EmptyState, SectionTitle, Spinner } from "@/components/ui";
import { ElementLine } from "@/components/ElementLine";
import { JsonBlock } from "@/components/JsonBlock";

export default function ParserPage() {
  const [parsed, setParsed] = useState<ParsedScreenplay | null>(null);
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openScene, setOpenScene] = useState<string | null>(null);
  const [jsonScene, setJsonScene] = useState<string | null>(null);

  const run = async (saveToDb: boolean) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/parse", { method: saveToDb ? "POST" : "GET" });
      const data = await res.json();
      if (!data.ok) throw new Error(data.error);
      setParsed(data.parsed);
      setSaved(saveToDb);
    } catch (e) {
      setError(e instanceof Error ? e.message : "파싱 실패");
    } finally {
      setLoading(false);
    }
  };

  const counts = (movie: Movie) => {
    let dialogue = 0;
    let action = 0;
    let character = 0;
    let transition = 0;
    for (const sc of movie.scenes)
      for (const el of sc.elements) {
        if (el.type === "dialogue") dialogue++;
        else if (el.type === "action") action++;
        else if (el.type === "character") character++;
        else if (el.type === "transition") transition++;
      }
    return { dialogue, action, character, transition };
  };

  return (
    <div className="space-y-6">
      <SectionTitle
        sub="Phase 2 — Markdown → 영화 분리 → Scene 분리 → Action/Dialogue 분리 → JSON. 이 단계에서는 카메라·감정을 만들지 않습니다."
        right={
          <div className="flex gap-2">
            <Button variant="outline" disabled={loading} onClick={() => run(false)}>
              {loading ? <Spinner label="파싱 중…" /> : "파싱만 실행"}
            </Button>
            <Button disabled={loading} onClick={() => run(true)}>
              {loading ? <Spinner label="파싱 중…" /> : "파싱 + DB 저장"}
            </Button>
          </div>
        }
      >
        Screenplay Parser
      </SectionTitle>

      {error && (
        <Card className="border-rose-500/30 px-4 py-3 text-xs text-rose-300">{error}</Card>
      )}

      {saved && (
        <Card className="border-emerald-500/30 bg-emerald-950/10 px-4 py-3 text-xs text-emerald-300">
          ✓ movies + scenes가 PostgreSQL에 저장되었습니다 (scene code 기준 upsert — 검수 이력 보존).
        </Card>
      )}

      {!parsed ? (
        <EmptyState>
          <div className="text-3xl">⚙️</div>
          <div className="mt-1">위 버튼을 눌러 data/movies.md를 파싱하세요</div>
          <div className="text-[11px] text-zinc-600">Python 구현과 동일한 규칙 (src/lib/parser)</div>
        </EmptyState>
      ) : (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2 text-[11px] text-zinc-500">
            <Badge tone="amber">{parsed.movies.length} movies</Badge>
            <Badge tone="sky">{parsed.totalScenes} scenes</Badge>
            <Badge tone="zinc">{parsed.totalLines} lines</Badge>
          </div>

          {parsed.movies.map((movie) => {
            const c = counts(movie);
            return (
              <Card key={movie.slug} className="overflow-hidden">
                <div className="flex flex-wrap items-center gap-3 border-b border-zinc-800 bg-zinc-900/60 px-5 py-4">
                  <div className="text-base font-bold text-zinc-50">{movie.title}</div>
                  <Badge tone="violet">{movie.scenes.length} scenes</Badge>
                  <div className="ml-auto flex flex-wrap gap-1.5">
                    <Badge tone="sky">대화 {c.dialogue}</Badge>
                    <Badge tone="zinc">액션 {c.action}</Badge>
                    <Badge tone="amber">인물 큐 {c.character}</Badge>
                    <Badge tone="rose">전환 {c.transition}</Badge>
                  </div>
                </div>
                <div className="px-3 py-2">
                  {movie.scenes.map((sc) => (
                    <div key={sc.code}>
                      <button
                        onClick={() => setOpenScene(openScene === sc.code ? null : sc.code)}
                        className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left transition hover:bg-zinc-800/60"
                      >
                        <span className="font-mono text-[11px] text-amber-400/80">{sc.code}</span>
                        <span className="text-xs font-semibold text-zinc-200">{sc.heading}</span>
                        <span className="text-[10px] text-zinc-600">
                          {sc.location ?? "?"} · {sc.timeOfDay ?? "시간정보 없음"} · L{sc.startLine}–{sc.endLine}
                        </span>
                        <span className="ml-auto text-[10px] text-zinc-500">
                          {openScene === sc.code ? "접기 ▲" : "펼치기 ▼"}
                        </span>
                      </button>
                      {openScene === sc.code && (
                        <div className="fade-up space-y-3 px-3 pb-4 pt-1">
                          <div className="rounded-lg border border-zinc-800 bg-zinc-950/60 p-3">
                            <div className="mb-1 flex items-center justify-between">
                              <span className="text-[10px] font-medium uppercase tracking-widest text-zinc-600">
                                Elements ({sc.elements.length})
                              </span>
                              <button
                                onClick={() => setJsonScene(jsonScene === sc.code ? null : sc.code)}
                                className="rounded px-2 py-0.5 text-[10px] font-medium text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200"
                              >
                                {jsonScene === sc.code ? "JSON 닫기" : "JSON 보기"}
                              </button>
                            </div>
                            <div className="space-y-0.5">
                              {sc.elements.map((el, i) => (
                                <ElementLine key={i} el={el} />
                              ))}
                            </div>
                          </div>
                          {jsonScene === sc.code && <JsonBlock data={sc} maxHeight={360} />}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
