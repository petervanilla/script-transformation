"use client";

import type { Beat } from "@/lib/analyzer/types";
import { Badge, Card } from "./ui";

export function ConfidenceBar({ value }: { value: number }) {
  const pct = Math.round(value * 100);
  const color = pct >= 75 ? "bg-emerald-400" : pct >= 60 ? "bg-amber-400" : "bg-rose-400";
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-zinc-800">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${pct}%` }} />
      </div>
      <span className="font-mono text-[10px] tabular-nums text-zinc-500">{pct}%</span>
    </div>
  );
}

export function BeatCard({ beat }: { beat: Beat }) {
  return (
    <Card className="px-4 py-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="font-mono text-[11px] font-bold text-amber-400">BEAT {String(beat.index).padStart(2, "0")}</span>
        {beat.speakers.map((s) => (
          <Badge key={s} tone="sky">{s}</Badge>
        ))}
        <div className="ml-auto">
          <ConfidenceBar value={beat.confidence} />
        </div>
      </div>

      <div className="mt-3 space-y-2 text-xs">
        <Row label="start" value={beat.startText} mono />
        <Row label="end" value={beat.endText} mono />

        <div className="grid gap-2 sm:grid-cols-2">
          <Field label="목표 (objective)" value={beat.objective} />
          <Field label="행동 (action)" value={beat.action} />
        </div>
        <div className="grid gap-2 sm:grid-cols-2">
          <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
            <div className="text-[9px] font-medium uppercase tracking-widest text-zinc-600">emotion before → after</div>
            <div className="mt-1 text-xs text-zinc-200">
              <span className="text-violet-300">{beat.emotionBefore}</span>
              <span className="mx-1.5 text-zinc-600">→</span>
              <span className="text-violet-300">{beat.emotionAfter}</span>
            </div>
          </div>
          <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
            <div className="text-[9px] font-medium uppercase tracking-widest text-zinc-600">relationship change</div>
            <div className="mt-1 text-xs text-zinc-200">{beat.relationshipChange}</div>
          </div>
        </div>

        {beat.conflict && (
          <div className="rounded-lg border border-rose-500/25 bg-rose-950/15 px-3 py-2 text-xs text-rose-300">
            ⚡ 갈등 (conflict): {beat.conflict}
          </div>
        )}

        {beat.evidence.length > 0 && (
          <div>
            <div className="mb-1 text-[9px] font-medium uppercase tracking-widest text-zinc-600">
              evidence — 원문 근거
            </div>
            <div className="flex flex-wrap gap-1.5">
              {beat.evidence.map((e, i) => (
                <span
                  key={i}
                  className="rounded-md bg-amber-500/5 px-2 py-1 font-mono text-[10px] leading-snug text-amber-200/80 ring-1 ring-amber-500/15"
                >
                  “{e}”
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}

function Row({ label, value, mono = false }: { label: string; value: string; mono?: boolean }) {
  return (
    <div className="flex gap-2">
      <span className="w-16 shrink-0 pt-px text-[9px] font-medium uppercase tracking-widest text-zinc-600">
        {label}
      </span>
      <span className={`text-zinc-300 ${mono ? "font-mono text-[11px]" : ""}`}>{value}</span>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg border border-zinc-800 bg-zinc-950/50 px-3 py-2">
      <div className="text-[9px] font-medium uppercase tracking-widest text-zinc-600">{label}</div>
      <div className="mt-1 text-xs leading-relaxed text-zinc-200">{value}</div>
    </div>
  );
}
