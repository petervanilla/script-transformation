"use client";

import { useState } from "react";

export function JsonBlock({ data, maxHeight = 420 }: { data: unknown; maxHeight?: number }) {
  const [copied, setCopied] = useState(false);
  const text = JSON.stringify(data, null, 2);

  return (
    <div className="relative overflow-hidden rounded-lg border border-zinc-800 bg-zinc-950">
      <div className="flex items-center justify-between border-b border-zinc-800 bg-zinc-900/60 px-3 py-1.5">
        <span className="text-[10px] font-medium uppercase tracking-widest text-zinc-500">JSON</span>
        <button
          onClick={() => {
            navigator.clipboard?.writeText(text).then(() => {
              setCopied(true);
              setTimeout(() => setCopied(false), 1200);
            });
          }}
          className="rounded px-2 py-0.5 text-[10px] font-medium text-zinc-400 transition hover:bg-zinc-800 hover:text-zinc-200"
        >
          {copied ? "복사됨 ✓" : "복사"}
        </button>
      </div>
      <pre
        className="overflow-auto p-3 font-mono text-[11px] leading-relaxed text-zinc-300"
        style={{ maxHeight }}
      >
        {text}
      </pre>
    </div>
  );
}
