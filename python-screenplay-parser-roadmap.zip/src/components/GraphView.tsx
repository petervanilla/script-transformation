"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import type { DirectorGraph, DkgEdge, DkgNode, NodeKind } from "@/lib/dkg/types";
import { KIND_COLORS, MACRO_KINDS } from "@/lib/dkg/types";

interface SimNode {
  id: string;
  kind: NodeKind;
  label: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  deg: number;
}

const RADIUS_BY_KIND: Partial<Record<NodeKind, number>> = {
  movie: 26,
  sequence: 20,
  scene: 13,
  beat: 7,
  intent: 6,
  character: 14,
  location: 10,
  emotion: 11,
  motif: 10,
  music: 9,
};

const ALL_KINDS: NodeKind[] = [
  "movie",
  "sequence",
  "scene",
  "beat",
  "intent",
  "character",
  "location",
  "emotion",
  "motif",
  "music",
];

const KIND_LABEL: Record<string, string> = {
  movie: "Movie",
  sequence: "Sequence",
  scene: "Scene",
  beat: "Beat",
  intent: "Intent",
  character: "Character",
  location: "Location",
  emotion: "Emotion",
  motif: "Motif",
  music: "Music",
};

/** Run a lightweight force-directed simulation; returns positioned nodes. */
function simulate(nodes: SimNode[], edges: { s: string; t: string }[], iters = 320) {
  const W = 900;
  const H = 640;
  const byId = new Map(nodes.map((n) => [n.id, n]));
  for (let it = 0; it < iters; it++) {
    const cool = 1 - it / iters;
    // repulsion (pairs)
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i];
        const b = nodes[j];
        let dx = a.x - b.x;
        let dy = a.y - b.y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 0.01) {
          dx = Math.random() - 0.5;
          dy = Math.random() - 0.5;
          d2 = dx * dx + dy * dy + 0.01;
        }
        const d = Math.sqrt(d2);
        const f = 5200 / d2;
        const fx = (dx / d) * f;
        const fy = (dy / d) * f;
        a.vx += fx;
        a.vy += fy;
        b.vx -= fx;
        b.vy -= fy;
      }
    }
    // springs (edges)
    for (const e of edges) {
      const a = byId.get(e.s);
      const b = byId.get(e.t);
      if (!a || !b) continue;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
      const target = 70;
      const f = (d - target) * 0.04;
      const fx = (dx / d) * f;
      const fy = (dy / d) * f;
      a.vx += fx;
      a.vy += fy;
      b.vx -= fx;
      b.vy -= fy;
    }
    // centering + integrate
    for (const n of nodes) {
      n.vx += (W / 2 - n.x) * 0.01;
      n.vy += (H / 2 - n.y) * 0.01;
      n.x += n.vx * 0.08 * cool;
      n.y += n.vy * 0.08 * cool;
      n.vx *= 0.85;
      n.vy *= 0.85;
      n.x = Math.max(30, Math.min(W - 30, n.x));
      n.y = Math.max(30, Math.min(H - 30, n.y));
    }
  }
}

export function GraphView({ graph }: { graph: DirectorGraph }) {
  const [filters, setFilters] = useState<Set<NodeKind>>(new Set(MACRO_KINDS));
  const [selected, setSelected] = useState<string | null>(null);
  const [hover, setHover] = useState<string | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const dragRef = useRef<{ id: string; ox: number; oy: number } | null>(null);
  const panRef = useRef<{ tx: number; ty: number; scale: number }>({ tx: 0, ty: 0, scale: 1 });
  const [panTick, setPanTick] = useState(0);
  const [pos, setPos] = useState<Record<string, SimNode>>({});

  const { visNodes, visEdges } = useMemo(() => {
    const nodeMap = new Map(graph.nodes.map((n) => [n.id, n]));
    const vis: SimNode[] = graph.nodes
      .filter((n) => filters.has(n.kind))
      .map((n) => {
        const angle = (ALL_KINDS.indexOf(n.kind) / ALL_KINDS.length) * Math.PI * 2;
        const ring = 120 + Math.random() * 180;
        return {
          id: n.id,
          kind: n.kind,
          label: n.label,
          x: 450 + Math.cos(angle) * ring + (Math.random() - 0.5) * 40,
          y: 320 + Math.sin(angle) * ring + (Math.random() - 0.5) * 40,
          vx: 0,
          vy: 0,
          r: RADIUS_BY_KIND[n.kind] ?? 6,
          deg: 0,
        };
      });
    const visIds = new Set(vis.map((n) => n.id));
    const edges: { s: string; t: string }[] = graph.edges
      .filter((e) => visIds.has(e.source) && visIds.has(e.target))
      .map((e) => ({ s: e.source, t: e.target }));
    edges.forEach((e) => {
      const a = vis.find((n) => n.id === e.s);
      const b = vis.find((n) => n.id === e.t);
      if (a) a.deg++;
      if (b) b.deg++;
    });
    return { visNodes: vis, visEdges: edges };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [graph, filters]);

  useEffect(() => {
    if (!visNodes.length) {
      setPos({});
      return;
    }
    const copy: SimNode[] = visNodes.map((n) => ({ ...n }));
    simulate(copy, visEdges);
    setPos(Object.fromEntries(copy.map((n) => [n.id, n])));
    panRef.current = { tx: 0, ty: 0, scale: 1 };
    setPanTick((t) => t + 1);
  }, [visNodes, visEdges]);

  const toggleKind = (k: NodeKind) => {
    setFilters((prev) => {
      const next = new Set(prev);
      if (next.has(k)) next.delete(k);
      else next.add(k);
      return next;
    });
  };

  const selectedNode = selected ? graph.nodes.find((n) => n.id === selected) : null;
  const neighbors = useMemo(() => {
    if (!selected) return new Set<string>();
    const set = new Set<string>();
    for (const e of graph.edges) {
      if (e.source === selected) set.add(e.target);
      if (e.target === selected) set.add(e.source);
    }
    return set;
  }, [selected, graph.edges]);

  // pointer handlers for pan + node drag (screen → svg coords)
  const toSvg = (clientX: number, clientY: number) => {
    const svg = svgRef.current;
    if (!svg) return { x: 0, y: 0 };
    const rect = svg.getBoundingClientRect();
    const { scale, tx, ty } = panRef.current;
    return {
      x: (clientX - rect.left - tx) / scale,
      y: (clientY - rect.top - ty) / scale,
    };
  };

  const onPointerDown = (e: React.PointerEvent) => {
    (e.target as Element).setPointerCapture?.(e.pointerId);
    const pt = toSvg(e.clientX, e.clientY);
    // hit test nodes (topmost)
    let hit: string | null = null;
    for (const id in pos) {
      const n = pos[id];
      if ((n.x - pt.x) ** 2 + (n.y - pt.y) ** 2 <= (n.r + 4) ** 2) hit = id;
    }
    if (hit) {
      dragRef.current = { id: hit, ox: pt.x - pos[hit].x, oy: pt.y - pos[hit].y };
      setSelected(hit);
    } else {
      dragRef.current = { id: "__pan", ox: e.clientX - panRef.current.tx, oy: e.clientY - panRef.current.ty };
    }
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const d = dragRef.current;
    if (!d) return;
    if (d.id === "__pan") {
      panRef.current.tx = e.clientX - d.ox;
      panRef.current.ty = e.clientY - d.oy;
      setPanTick((t) => t + 1);
    } else {
      const pt = toSvg(e.clientX, e.clientY);
      setPos((prev) => {
        const n = prev[d.id];
        if (!n) return prev;
        return { ...prev, [d.id]: { ...n, x: pt.x - d.ox, y: pt.y - d.oy } };
      });
    }
  };
  const onPointerUp = () => {
    dragRef.current = null;
  };
  const onWheel = (e: React.WheelEvent) => {
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    panRef.current.scale = Math.max(0.3, Math.min(3, panRef.current.scale * delta));
    setPanTick((t) => t + 1);
  };

  void panTick;
  const { scale, tx, ty } = panRef.current;

  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_300px]">
      <div className="space-y-3">
        {/* filters */}
        <div className="flex flex-wrap gap-1.5">
          {ALL_KINDS.map((k) => {
            const active = filters.has(k);
            return (
              <button
                key={k}
                onClick={() => toggleKind(k)}
                className={`flex items-center gap-1.5 rounded-md px-2 py-1 text-[10px] font-medium ring-1 transition ${
                  active
                    ? "bg-zinc-800 text-zinc-100 ring-zinc-600"
                    : "bg-transparent text-zinc-600 ring-zinc-800 hover:text-zinc-400"
                }`}
              >
                <span className="h-2 w-2 rounded-full" style={{ background: KIND_COLORS[k] }} />
                {KIND_LABEL[k]}
                <span className="tabular-nums text-zinc-500">
                  {graph.nodes.filter((n) => n.kind === k).length}
                </span>
              </button>
            );
          })}
        </div>

        <div className="relative overflow-hidden rounded-xl border border-zinc-800 bg-zinc-950">
          <svg
            ref={svgRef}
            viewBox="0 0 900 640"
            className="h-[640px] w-full touch-none cursor-grab active:cursor-grabbing"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
            onWheel={onWheel}
          >
            <g transform={`translate(${tx} ${ty}) scale(${scale})`}>
              {/* edges */}
              {visEdges.map((e, i) => {
                const a = pos[e.s];
                const b = pos[e.t];
                if (!a || !b) return null;
                const dim = selected && e.s !== selected && e.t !== selected;
                return (
                  <line
                    key={i}
                    x1={a.x}
                    y1={a.y}
                    x2={b.x}
                    y2={b.y}
                    stroke={dim ? "#27272a" : "#3f3f46"}
                    strokeWidth={1}
                  />
                );
              })}
              {/* nodes */}
              {Object.values(pos).map((n) => {
                const isSel = n.id === selected;
                const isNb = neighbors.has(n.id);
                const dim = selected && !isSel && !isNb;
                const color = KIND_COLORS[n.kind] ?? "#71717a";
                const showLabel =
                  ["movie", "sequence", "scene", "character", "location", "emotion", "motif"].includes(
                    n.kind
                  ) || isSel || hover === n.id;
                return (
                  <g
                    key={n.id}
                    transform={`translate(${n.x} ${n.y})`}
                    className="cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelected(isSel ? null : n.id);
                    }}
                    onPointerEnter={() => setHover(n.id)}
                    onPointerLeave={() => setHover(null)}
                    opacity={dim ? 0.25 : 1}
                  >
                    {isSel && <circle r={n.r + 5} fill="none" stroke={color} strokeWidth={1.5} opacity={0.6} />}
                    <circle r={n.r} fill={color} fillOpacity={isNb ? 1 : 0.85} stroke="#0a0a0a" strokeWidth={1.5} />
                    {showLabel && (
                      <text
                        y={n.r + 12}
                        textAnchor="middle"
                        className="pointer-events-none select-none fill-zinc-300 font-mono"
                        style={{ fontSize: Math.min(11, 9 + (n.kind === "movie" ? 3 : 0)) }}
                      >
                        {n.label.length > 22 ? n.label.slice(0, 22) + "…" : n.label}
                      </text>
                    )}
                  </g>
                );
              })}
            </g>
          </svg>
          <div className="pointer-events-none absolute bottom-2 left-3 text-[10px] text-zinc-600">
            드래그: 이동 · 노드 끌기 · 휠: 줌 · 클릭: 인접 관계 하이라이트
          </div>
        </div>
      </div>

      {/* inspector */}
      <div className="space-y-3">
        {selectedNode ? (
          <NodeInspector
            node={selectedNode}
            neighbors={graph.edges
              .filter((e) => e.source === selectedNode.id || e.target === selectedNode.id)
              .map((e) => ({
                kind: e.kind,
                other: graph.nodes.find(
                  (n) => n.id === (e.source === selectedNode.id ? e.target : e.source)
                ),
                dir: e.source === selectedNode.id ? "out" : "in",
              }))
              .filter((x) => x.other)}
            onClose={() => setSelected(null)}
          />
        ) : (
          <div className="rounded-xl border border-dashed border-zinc-800 px-4 py-8 text-center text-xs text-zinc-500">
            노드를 클릭하면 연결된 관계를 볼 수 있습니다
          </div>
        )}
      </div>
    </div>
  );
}

function NodeInspector({
  node,
  neighbors,
  onClose,
}: {
  node: DkgNode;
  neighbors: { kind: string; other?: DkgNode; dir: string }[];
  onClose: () => void;
}) {
  const color = KIND_COLORS[node.kind] ?? "#71717a";
  return (
    <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="h-3 w-3 rounded-full" style={{ background: color }} />
          <div>
            <div className="text-[10px] font-medium uppercase tracking-widest text-zinc-500">
              {node.kind}
            </div>
            <div className="text-sm font-semibold text-zinc-100">{node.label}</div>
          </div>
        </div>
        <button onClick={onClose} className="text-zinc-600 hover:text-zinc-300">
          ✕
        </button>
      </div>

      {Object.keys(node.properties).length > 0 && (
        <div className="mt-3 space-y-1">
          {Object.entries(node.properties).map(([k, v]) => (
            <div key={k} className="flex gap-2 text-[11px]">
              <span className="w-28 shrink-0 text-zinc-500">{k}</span>
              <span className="text-zinc-300">
                {typeof v === "string" ? v : JSON.stringify(v)}
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="mt-4">
        <div className="mb-1.5 text-[10px] font-medium uppercase tracking-widest text-zinc-500">
          관계 ({neighbors.length})
        </div>
        <div className="max-h-72 space-y-1 overflow-auto">
          {neighbors.map((nb, i) => (
            <div key={i} className="flex items-center gap-1.5 text-[11px]">
              {nb.dir === "out" ? (
                <span className="text-sky-400">→</span>
              ) : (
                <span className="text-violet-400">←</span>
              )}
              <span className="rounded bg-zinc-800 px-1.5 py-0.5 font-mono text-[9px] text-zinc-400">
                {nb.kind}
              </span>
              <span className="text-zinc-300">{nb.other?.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
