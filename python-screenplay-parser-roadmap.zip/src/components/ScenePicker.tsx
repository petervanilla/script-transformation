"use client";

import { useEffect, useMemo, useState } from "react";
import type { Movie } from "@/lib/parser/types";

export interface SceneSelection {
  movieSlug: string;
  sceneCode: string;
}

export function ScenePicker({
  value,
  onChange,
}: {
  value: SceneSelection;
  onChange: (v: SceneSelection) => void;
}) {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/parse")
      .then((r) => r.json())
      .then((d) => {
        if (d.ok && d.parsed?.movies?.length) {
          setMovies(d.parsed.movies);
          const first = d.parsed.movies[0];
          const hasSelection = d.parsed.movies.some((m: Movie) => m.slug === value.movieSlug);
          if (!hasSelection && first?.scenes?.length) {
            onChange({ movieSlug: first.slug, sceneCode: first.scenes[0].code });
          }
        } else {
          setError("movies.md를 찾을 수 없습니다.");
        }
      })
      .catch(() => setError("목록을 불러오지 못했습니다."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const scenes = useMemo(
    () => movies.find((m) => m.slug === value.movieSlug)?.scenes ?? [],
    [movies, value.movieSlug]
  );

  if (error) {
    return <div className="text-xs text-rose-400">{error}</div>;
  }

  return (
    <div className="flex flex-wrap items-center gap-3">
      <label className="flex items-center gap-2 text-xs text-zinc-400">
        영화
        <select
          value={value.movieSlug}
          onChange={(e) => {
            const m = movies.find((x) => x.slug === e.target.value);
            onChange({
              movieSlug: e.target.value,
              sceneCode: m?.scenes?.[0]?.code ?? "",
            });
          }}
          className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-zinc-200 outline-none focus:border-amber-500/60"
        >
          {movies.map((m) => (
            <option key={m.slug} value={m.slug}>
              {m.title} ({m.scenes.length} scenes)
            </option>
          ))}
        </select>
      </label>
      <label className="flex items-center gap-2 text-xs text-zinc-400">
        Scene
        <select
          value={value.sceneCode}
          onChange={(e) => onChange({ ...value, sceneCode: e.target.value })}
          className="rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-xs text-zinc-200 outline-none focus:border-amber-500/60"
        >
          {scenes.map((s) => (
            <option key={s.code} value={s.code}>
              {s.code} · {s.heading}
            </option>
          ))}
        </select>
      </label>
    </div>
  );
}
