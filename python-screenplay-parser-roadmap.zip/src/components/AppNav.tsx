"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const LINKS = [
  { href: "/", label: "대시보드" },
  { href: "/upload", label: "📂 업로드" },
  { href: "/graph", label: "🕸️ DKG" },
  { href: "/diagnose", label: "1. 진단" },
  { href: "/parser", label: "2. 파서" },
  { href: "/analysis", label: "3·4. Beat" },
  { href: "/review", label: "6. 검수" },
];

export function AppNav() {
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-40 border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur">
      <div className="mx-auto flex w-full max-w-7xl items-center gap-6 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/15 text-base ring-1 ring-amber-500/40">
            🎬
          </span>
          <span className="text-sm font-semibold tracking-tight text-zinc-100">
            Screenplay Converter
            <span className="ml-2 hidden text-[10px] font-normal uppercase tracking-widest text-zinc-500 sm:inline">
              Director Dataset
            </span>
          </span>
        </Link>
        <nav className="ml-auto flex items-center gap-1 overflow-x-auto">
          {LINKS.map((l) => {
            const active = pathname === l.href;
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`whitespace-nowrap rounded-md px-2.5 py-1.5 text-xs font-medium transition ${
                  active
                    ? "bg-amber-500/15 text-amber-300 ring-1 ring-amber-500/30"
                    : "text-zinc-400 hover:bg-zinc-800/70 hover:text-zinc-200"
                }`}
              >
                {l.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
