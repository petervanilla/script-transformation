"use client";

import type { ButtonHTMLAttributes, ReactNode } from "react";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <div className={`rounded-xl border border-zinc-800 bg-zinc-900/50 ${className}`}>
      {children}
    </div>
  );
}

type BadgeTone = "zinc" | "amber" | "sky" | "emerald" | "rose" | "violet";
const BADGE_TONES: Record<BadgeTone, string> = {
  zinc: "bg-zinc-800 text-zinc-300 ring-zinc-700",
  amber: "bg-amber-500/10 text-amber-300 ring-amber-500/30",
  sky: "bg-sky-500/10 text-sky-300 ring-sky-500/30",
  emerald: "bg-emerald-500/10 text-emerald-300 ring-emerald-500/30",
  rose: "bg-rose-500/10 text-rose-300 ring-rose-500/30",
  violet: "bg-violet-500/10 text-violet-300 ring-violet-500/30",
};

export function Badge({
  children,
  tone = "zinc",
  className = "",
}: {
  children: ReactNode;
  tone?: BadgeTone;
  className?: string;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-medium ring-1 ${BADGE_TONES[tone]} ${className}`}
    >
      {children}
    </span>
  );
}

type ButtonVariant = "primary" | "ghost" | "danger" | "success" | "outline";
const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary:
    "bg-amber-500 text-zinc-950 hover:bg-amber-400 disabled:hover:bg-amber-500/60",
  success:
    "bg-emerald-500/90 text-zinc-950 hover:bg-emerald-400 disabled:hover:bg-emerald-500/60",
  danger: "bg-rose-500/90 text-white hover:bg-rose-400 disabled:hover:bg-rose-500/60",
  ghost: "bg-zinc-800/70 text-zinc-200 hover:bg-zinc-700/70",
  outline: "border border-zinc-700 text-zinc-300 hover:border-zinc-500 hover:text-zinc-100",
};

export function Button({
  children,
  variant = "primary",
  className = "",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  return (
    <button
      className={`inline-flex items-center justify-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold transition disabled:cursor-not-allowed disabled:opacity-60 ${BUTTON_VARIANTS[variant]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

export function Stat({
  label,
  value,
  hint,
  tone = "zinc",
}: {
  label: string;
  value: ReactNode;
  hint?: string;
  tone?: BadgeTone;
}) {
  return (
    <Card className="px-4 py-3.5">
      <div className="text-[11px] font-medium uppercase tracking-wider text-zinc-500">{label}</div>
      <div
        className={`mt-1 text-2xl font-bold tabular-nums ${
          tone === "amber"
            ? "text-amber-300"
            : tone === "emerald"
              ? "text-emerald-300"
              : tone === "rose"
                ? "text-rose-300"
                : tone === "sky"
                  ? "text-sky-300"
                  : "text-zinc-100"
        }`}
      >
        {value}
      </div>
      {hint ? <div className="mt-0.5 text-[11px] text-zinc-500">{hint}</div> : null}
    </Card>
  );
}

export function SectionTitle({
  children,
  sub,
  right,
}: {
  children: ReactNode;
  sub?: string;
  right?: ReactNode;
}) {
  return (
    <div className="mb-4 flex flex-wrap items-end justify-between gap-2">
      <div>
        <h2 className="text-base font-semibold text-zinc-100">{children}</h2>
        {sub ? <p className="mt-0.5 text-xs text-zinc-500">{sub}</p> : null}
      </div>
      {right}
    </div>
  );
}

export function Spinner({ label = "처리 중…" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 text-xs text-zinc-400">
      <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-zinc-600 border-t-amber-400" />
      {label}
    </div>
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-zinc-800 py-14 text-center text-sm text-zinc-500">
      {children}
    </div>
  );
}
