import type { ScreenplayElement } from "@/lib/parser/types";

const STYLES: Record<string, { cls: string; label: string }> = {
  action: { cls: "text-zinc-300", label: "action" },
  character: { cls: "text-sky-300 font-semibold tracking-wide", label: "character" },
  dialogue: { cls: "text-zinc-100", label: "dialogue" },
  parenthetical: { cls: "text-violet-300 italic", label: "parenthetical" },
  transition: { cls: "text-rose-400 font-semibold tracking-widest", label: "transition" },
  montage: { cls: "text-amber-400 font-bold tracking-widest", label: "montage" },
  end_montage: { cls: "text-amber-400 font-bold tracking-widest", label: "end_montage" },
  end_marker: { cls: "text-amber-200 font-semibold", label: "end" },
  blank: { cls: "text-zinc-700", label: "blank" },
  scene_heading: { cls: "text-amber-300 font-semibold", label: "heading" },
};

const TEXT_COLOR: Record<string, string> = {
  action: "text-zinc-600",
  character: "text-sky-400/80",
  dialogue: "text-zinc-600",
  parenthetical: "text-violet-400/70",
  transition: "text-rose-400/80",
  montage: "text-amber-400/80",
  end_montage: "text-amber-400/80",
  end_marker: "text-amber-200/70",
  blank: "text-transparent",
  scene_heading: "text-amber-400/80",
};

export function ElementLine({ el, showLabels = true }: { el: ScreenplayElement; showLabels?: boolean }) {
  const style = STYLES[el.type] ?? STYLES.action;
  return (
    <div className="group flex gap-2 py-0.5">
      {showLabels && (
        <span className={`w-20 shrink-0 pt-0.5 font-mono text-[9px] uppercase tracking-wider ${TEXT_COLOR[el.type] ?? "text-zinc-600"}`}>
          {style.label}
        </span>
      )}
      <span className={`flex-1 font-mono text-[12px] leading-relaxed ${style.cls}`}>{el.text || "·"}</span>
    </div>
  );
}
