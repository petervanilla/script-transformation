import path from "path";

/** Path to the raw source screenplay (preserved as-is, never rewritten). */
export const DATA_FILE = path.join(process.cwd(), "data", "movies.md");

export function truncate(s: string, n: number): string {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
}
