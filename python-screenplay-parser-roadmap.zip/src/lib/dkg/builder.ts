/** DKG builder — turns a parsed screenplay into a Director Knowledge Graph.

Deterministic & explainable (Phase 1–7 baseline). Every relationship and
craft decision is derived from the source text so the LLM can later enrich
but never silently fabricate.
*/

import { parseScreenplay } from "../parser";
import type { Movie, Scene } from "../parser/types";
import { analyzeScene } from "../analyzer/beat_analyzer";
import type { SceneAnalysis } from "../analyzer/types";
import { planShot } from "../analyzer/shot_planner";
import type { Beat } from "../analyzer/types";
import type { DkgEdge, DkgNode, DirectorGraph, NodeKind } from "./types";

const MOTIF_PATTERNS: { re: RegExp; motif: string }[] = [
  { re: /\bcount|counts|practice|practicing|practices\b/i, motif: "repetition-practice" },
  { re: /\bsymmetr|perfect rows|neat rows|lines up\b/i, motif: "symmetry-order" },
  { re: /\bpendulum|swings?\b/i, motif: "pendulum-motion" },
  { re: /\bsun\b/i, motif: "sun-light" },
  { re: /\bhand|hands|fingers\b/i, motif: "hands-focus" },
  { re: /\bmirror\b/i, motif: "reflection" },
  { re: /\bdoor|doorframe\b/i, motif: "threshold" },
];

function lightsFor(scene: Scene, text: string): { lighting: string } {
  const tod = (scene.timeOfDay ?? "").toUpperCase();
  const isNight = /NIGHT|DUSK|EVENING/.test(tod);
  const isDawn = /DAWN|MORNING|A\.M/.test(tod);
  const isGolden = /SUNSET|SUNRISE|DUSK|DAWN/.test(tod);
  const isRed = /red light/i.test(text);
  if (isRed) return { lighting: "red safelight (darkroom), single-source practical" };
  if (/\b분노|anger|shout/i.test(text)) return { lighting: "high-contrast hard key, deep shadows" };
  if (/\bsad|weep|tremble|tears|stare/i.test(text)) return { lighting: "low-key, muted cool tones" };
  if (scene.interior === false && isGolden) return { lighting: "golden hour, long directional shadows" };
  if (scene.interior === false) return { lighting: "hard daylight, natural fill" };
  if (isNight) return { lighting: "practical low-key, warm motivated sources" };
  if (isDawn) return { lighting: "soft morning daylight, high-key motivated" };
  return { lighting: "balanced ambient, soft motivated key" };
}

function compositionFor(beat: Beat, scene: Scene): string {
  if (/\bmontage\b/i.test(beat.evidence.join(" "))) return "grid montage framing, rhythmic cutting";
  if (beat.speakers.length >= 2) return "symmetrical two-shot, shared centered axis";
  if (beat.speakers.length === 1) return "rule of thirds, subject-led framing";
  if (/\bwalks?|paces?|runs?\b/i.test(beat.action)) return "lead-room tracking composition";
  return "environmental wide, figure-in-space";
}

function editingFor(scene: Scene): string {
  const tr = scene.elements.find((e) => e.type === "transition")?.text ?? "";
  if (/SMASH/.test(tr)) return "smash cut";
  if (/DISSOLVE/.test(tr)) return "dissolve";
  if (/FADE/.test(tr)) return "fade";
  if (scene.elements.some((e) => e.type === "montage")) return "parallel montage editing";
  return "hard cut on action";
}

function performanceFor(beat: Beat): { performance: string } {
  return {
    performance: `${beat.action || beat.objective}. tempo: ${beat.emotionAfter}`,
  };
}

interface MusicHit {
  key: string;
  label: string;
  evidence: string;
}
function musicIn(text: string): MusicHit[] {
  const hits: MusicHit[] = [];
  const seen = new Set<string>();
  const add = (key: string, label: string, evidence: string) => {
    if (!seen.has(key)) {
      seen.add(key);
      hits.push({ key, label, evidence });
    }
  };
  let m = text.match(/"([^"]{3,60})"/);
  if (/\bbeatles|all you need is love|paul mccartney/i.test(text)) {
    add("diegetic-beatles", "Diegetic: The Beatles", "All You Need Is Love");
  }
  if (/\bradio\b/i.test(text)) add("diegetic-radio", "Diegetic radio source", "tiny radio");
  if (/\bhum|humming\b/i.test(text)) add("source-hum", "Character humming", "hums along");
  if (/\bengine noises?|laughs?\b/i.test(text)) add("vocal-sfx", "Vocal SFX", m?.[0] ?? "");
  return hits;
}

function actLabel(i: number, n: number, scene: Scene): string {
  const acts = n >= 6 ? 3 : n >= 3 ? 2 : 1;
  const idx = Math.min(acts - 1, Math.floor((i / n) * acts));
  return ["Act I — Setup", "Act II — Confrontation", "Act III — Resolution"][idx] ?? "Act I — Setup";
}

function speakerOf(elements: Scene["elements"], dialogueLine: number): string | null {
  for (let i = elements.length - 1; i >= 0; i--) {
    if (elements[i].line < dialogueLine && elements[i].type === "character") {
      return elements[i].character ?? null;
    }
  }
  return null;
}

/** Build relationships between characters from explicit textual evidence. */
function detectRelations(movie: Movie): {
  edges: DkgEdge[];
  relations: Record<string, { kind: string; target: string; evidence: string }[]>;
} {
  const edges: DkgEdge[] = [];
  const rels: Record<string, { kind: string; target: string; evidence: string }[]> = {};

  const recordEdge = (src: string, dst: string, kind: string, evidence: string) => {
    if (src === dst) return;
    const exists = edges.some((e) => e.source === src && e.target === dst && e.kind === kind);
    if (!exists) edges.push({ source: src, target: dst, kind, properties: { evidence } });
  };

  const addRel = (a: string, b: string, kind: string, evidence: string, reverse?: [string, string]) => {
    const aId = `character:${a}`;
    const bId = `character:${b}`;
    if (aId === bId) return;
    recordEdge(aId, bId, kind, evidence);
    (rels[a] ??= []).push({ kind, target: b, evidence });
    if (reverse) {
      const [rk] = reverse;
      recordEdge(bId, aId, rk, evidence);
      (rels[b] ??= []).push({ kind: rk, target: a, evidence });
    }
  };

  for (const scene of movie.scenes) {
    const present = new Set<string>();
    scene.elements.forEach((e) => {
      if (e.type === "character" && e.character) present.add(e.character);
    });
    const text = scene.elements.map((e) => e.text).join(" ");

    // 1) Vocative: a character's dialogue says "Daddy"/"Mom" → CHILD_OF the other present character
    scene.elements.forEach((el) => {
      if (el.type !== "dialogue") return;
      const speaker = speakerOf(scene.elements, el.line);
      if (!speaker) return;
      // Vocative only at the START of the line (avoids quotes like "Dear Daddy...")
      const voc = /^\s*(daddy|dad|papa|mom|mommy|mother)\b/i.exec(el.text);
      if (voc) {
        const target = [...present].find((c) => c !== speaker);
        if (target) {
          const isFather = /dad/i.test(voc[0]);
          addRel(
            speaker,
            target,
            isFather ? "CHILD_OF" : "CHILD_OF",
            `"${el.text.slice(0, 60)}"`,
            isFather ? ["FATHER_OF", speaker] : ["MOTHER_OF", speaker]
          );
        }
      }
    });

    // 2) Possessive: "SAM's daughter/son" → PARENT_OF
    const poss = /\b([A-Z][A-Z'\-]+)'S (DAUGHTER|SON|CHILD|WIFE|HUSBAND)\b/g;
    let pm: RegExpExecArray | null;
    while ((pm = poss.exec(text)) !== null) {
      const a = pm[1];
      const relWord = pm[2];
      const b = [...present].find((c) => c !== a);
      if (b) {
        const kind =
          relWord === "WIFE" || relWord === "HUSBAND" ? "MARRIED_TO" : "PARENT_OF";
        addRel(a, b, kind, `"${a}'s ${relWord.toLowerCase()}"`);
      }
    }

    // 3) Love / affection: a physical affection action (hug/hold/embrace/wrap)
    //    between co-present characters — far more reliable than the word "love".
    const affection = scene.elements.find((e) =>
      e.type === "action" && /\b(hug|hugs|hold|holds|holding|embrace|wrap|wraps|arms around)\b/i.test(e.text)
    );
    if (affection && present.size >= 2) {
      const [a, b] = [...present];
      if (a && b) addRel(a, b, "LOVES", `"${affection.text.slice(0, 60)}"`);
    }

    // 4) Separation / leaving
    if (/\bleaves?|left |walk(s|ed)? out|take her away\b/i.test(text) && present.size >= 2) {
      const [a, b] = [...present];
      if (a && b) addRel(a, b, "SEPARATED_FROM", "scene depicts parting");
    }

    // 5) Co-occurrence (weak link)
    const list = [...present];
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        addRel(list[i], list[j], "CO_OCCURS_WITH", `shared scene ${scene.code}`);
      }
    }
  }

  return { edges, relations: rels };
}

/** Build the full Director Knowledge Graph for one movie. */
export function buildDirectorGraph(movie: Movie): DirectorGraph {
  const nodes: DkgNode[] = [];
  const edges: DkgEdge[] = [];
  const pushNode = (n: DkgNode) => {
    if (!nodes.find((x) => x.id === n.id)) nodes.push(n);
  };
  const pushEdge = (e: DkgEdge) => edges.push(e);

  const movieId = `movie:${movie.slug}`;
  pushNode({
    id: movieId,
    kind: "movie",
    key: movie.slug,
    label: movie.title,
    properties: { title: movie.title, scenes: movie.scenes.length, characters: movie.characters.length },
  });

  // ---- Sequences (3-act structure) ----
  const n = movie.scenes.length;
  movie.scenes.forEach((scene, i) => {
    const acts = n >= 6 ? 3 : n >= 3 ? 2 : 1;
    const actIdx = Math.min(acts, Math.floor((i / n) * acts) + 1);
    const seqId = `sequence:SQ${String(actIdx).padStart(2, "0")}`;
    pushNode({
      id: seqId,
      kind: "sequence",
      key: `SQ${String(actIdx).padStart(2, "0")}`,
      label: actLabel(i, n, scene),
      properties: { act: actIdx },
    });
    pushEdge({ source: movieId, target: seqId, kind: "HAS_SEQUENCE" });

    // ---- Scene ----
    const sceneId = `scene:${scene.code}`;
    pushNode({
      id: sceneId,
      kind: "scene",
      key: scene.code,
      label: scene.heading,
      properties: {
        location: scene.location,
        interior: scene.interior,
        timeOfDay: scene.timeOfDay,
        index: scene.index,
      },
    });
    pushEdge({ source: seqId, target: sceneId, kind: "HAS_SCENE" });

    // ---- Location (shared) ----
    if (scene.location) {
      const locId = `location:${scene.location.toUpperCase()}`;
      pushNode({ id: locId, kind: "location", key: scene.location.toUpperCase(), label: scene.location, properties: {} });
      pushEdge({ source: sceneId, target: locId, kind: "SET_IN" });
    }

    // ---- Scene analysis → beats ----
    const analysis: SceneAnalysis = analyzeScene(scene);
    analysis.shots = analysis.beats.map((b, idx) =>
      planShot(b, `${scene.code}_SH${String(idx + 1).padStart(3, "0")}`)
    );

    analysis.beats.forEach((beat: Beat, bi) => {
      const beatId = `beat:${scene.code}_B${String(bi + 1).padStart(2, "0")}`;
      const fullText = [...beat.evidence, beat.action, beat.objective].join(" ");
      pushNode({
        id: beatId,
        kind: "beat",
        key: `${scene.code}_B${String(bi + 1).padStart(2, "0")}`,
        label: `Beat ${bi + 1}`,
        properties: {
          objective: beat.objective,
          emotionBefore: beat.emotionBefore,
          emotionAfter: beat.emotionAfter,
          conflict: beat.conflict,
          speakers: beat.speakers,
          confidence: beat.confidence,
          startText: beat.startText,
        },
      });
      pushEdge({ source: sceneId, target: beatId, kind: "HAS_BEAT" });

      // ---- Intent node ----
      const intentId = `intent:${scene.code}_B${String(bi + 1).padStart(2, "0")}`;
      pushNode({
        id: intentId,
        kind: "intent",
        key: `${scene.code}_B${String(bi + 1).padStart(2, "0")}`,
        label: "Director Intent",
        properties: { objective: beat.objective, sceneFunction: analysis.sceneFunction },
      });
      pushEdge({ source: beatId, target: intentId, kind: "HAS_INTENT" });

      const shot = analysis.shots[bi];
      const dimProps = (kind: NodeKind, label: string, props: Record<string, unknown>) => {
        const dimId = `${kind}:${scene.code}_B${String(bi + 1).padStart(2, "0")}`;
        pushNode({ id: dimId, kind, key: `${scene.code}_B${String(bi + 1).padStart(2, "0")}`, label, properties: props });
        pushEdge({ source: intentId, target: dimId, kind: "DESCRIBED_BY" });
        return dimId;
      };

      // ---- 9 intent dimensions (Beat → Intent children) ----
      dimProps("camera", "Camera", {
        shotSize: shot.shotSize,
        movement: shot.camera.movement,
        lens: shot.camera.lens,
        height: shot.camera.height,
      });
      dimProps("motion", "Motion", shot.motion);
      dimProps("prompt", "Prompt", { prompt: shot.prompt });
      dimProps("performance", "Performance", performanceFor(beat));
      dimProps("blocking", "Blocking", { action: beat.action, speakers: beat.speakers });
      dimProps("lighting", "Lighting", lightsFor(scene, fullText));
      dimProps("composition", "Composition", { composition: compositionFor(beat, scene) });
      dimProps("editing", "Editing", { editing: editingFor(scene) });
      // music: link to shared music node
      for (const m of musicIn(fullText)) {
        const mId = `music:${m.key}`;
        pushNode({ id: mId, kind: "music", key: m.key, label: m.label, properties: { evidence: m.evidence } });
        pushEdge({ source: intentId, target: mId, kind: "FEATURED_MUSIC" });
      }

      // ---- Emotion (shared entity) ----
      const emo = beat.emotionAfter && beat.emotionAfter !== "중립" ? beat.emotionAfter : beat.emotionBefore;
      if (emo && emo !== "중립") {
        const emoId = `emotion:${emo}`;
        pushNode({ id: emoId, kind: "emotion", key: emo, label: emo, properties: {} });
        pushEdge({ source: beatId, target: emoId, kind: "HAS_EMOTION", properties: { role: "after" } });
      }
      const emoBefore = beat.emotionBefore;
      if (emoBefore && emoBefore !== "중립" && emoBefore !== emo) {
        const emoId = `emotion:${emoBefore}`;
        pushNode({ id: emoId, kind: "emotion", key: emoBefore, label: emoBefore, properties: {} });
        pushEdge({ source: beatId, target: emoId, kind: "HAS_EMOTION", properties: { role: "before" } });
      }

      // ---- Motifs (shared) ----
      const motifText = fullText.toLowerCase();
      for (const { re, motif } of MOTIF_PATTERNS) {
        if (re.test(motifText)) {
          const mId = `motif:${motif}`;
          pushNode({ id: mId, kind: "motif", key: motif, label: motif, properties: {} });
          pushEdge({ source: beatId, target: mId, kind: "USES_VISUAL_MOTIF" });
        }
      }

      // ---- Shot node + VISUALIZED_AS ----
      const shotId = `shot:${shot.shotCode}`;
      pushNode({
        id: shotId,
        kind: "camera",
        key: shot.shotCode,
        label: shot.shotCode,
        properties: { shotSize: shot.shotSize, intent: shot.intent, subject: shot.subject, prompt: shot.prompt },
      });
      pushEdge({ source: beatId, target: shotId, kind: "VISUALIZED_AS" });
    });

    // ---- Characters APPEAR_IN (one edge per character-scene pair) ----
    const appeared = new Set<string>();
    scene.elements.forEach((el) => {
      if (el.type === "character" && el.character && !appeared.has(el.character)) {
        appeared.add(el.character);
        const charId = `character:${el.character}`;
        pushNode({ id: charId, kind: "character", key: el.character, label: el.character, properties: {} });
        pushEdge({ source: charId, target: sceneId, kind: "APPEARS_IN" });
      }
    });
  });

  // ---- Character relationships ----
  const { edges: relEdges, relations } = detectRelations(movie);
  relEdges.forEach((e) => {
    if (nodes.find((n) => n.id === e.source) && nodes.find((n) => n.id === e.target)) {
      pushEdge(e);
    }
  });

  // ---- Character index (for "click a character" view) ----
  const characterIndex: DirectorGraph["characterIndex"] = {};
  for (const name of movie.characters) {
    const charId = `character:${name}`;
    const appearEdges = edges.filter((e) => e.source === charId && e.kind === "APPEARS_IN");
    const scenes = appearEdges.map((e) => e.target.replace("scene:", ""));
    // find beats whose scene the character appears in, gather emotions + shots
    const emotions = new Set<string>();
    const shots = new Set<string>();
    for (const sc of scenes) {
      edges
        .filter((e) => e.source === `scene:${sc}` && e.kind === "HAS_BEAT")
        .forEach((be) => {
          edges
            .filter((e) => e.source === be.target && e.kind === "HAS_EMOTION")
            .forEach((ee) => emotions.add(ee.target.replace("emotion:", "")));
          edges
            .filter((e) => e.source === be.target && e.kind === "VISUALIZED_AS")
            .forEach((se) => shots.add(se.target.replace("shot:", "")));
        });
    }
    characterIndex[name] = {
      scenes,
      emotions: [...emotions],
      shots: [...shots],
      lines: movie.characterLines[name] ?? 0,
      relations: (relations[name] ?? []).map((r) => ({ kind: r.kind, target: r.target })),
    };
  }

  const kindCount = (k: NodeKind) => nodes.filter((n) => n.kind === k).length;
  return {
    source: "heuristic",
    movieTitle: movie.title,
    movieSlug: movie.slug,
    nodes,
    edges,
    stats: {
      nodes: nodes.length,
      edges: edges.length,
      scenes: movie.scenes.length,
      beats: kindCount("beat"),
      characters: movie.characters.length,
      locations: kindCount("location"),
      intents: kindCount("intent"),
      relationships: relEdges.length,
    },
    characterIndex,
  };
}

/** Build graphs for all movies in a screenplay text. */
export function buildAllGraphs(text: string, lines: string[]): DirectorGraph[] {
  const parsed = parseScreenplay(text, lines);
  return parsed.movies.map(buildDirectorGraph);
}
