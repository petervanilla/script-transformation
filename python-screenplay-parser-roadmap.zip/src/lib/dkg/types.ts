/** Director Knowledge Graph (DKG) — node/edge types.

The DKG stores a director's *reasoning*, not just script facts:
    Movie → Sequence → Scene → Beat → Intent
                                       ├─ Emotion / Camera / Blocking
                                       ├─ Performance / Lighting / Composition
                                       └─ Editing / Music / Prompt / Motion JSON

Entities that repeat and are worth querying across the whole film
(Character, Location, Emotion, Motif, Music) are SHARED nodes; the
per-beat craft decisions live under each Intent node.
*/

export type NodeKind =
  | "movie"
  | "sequence"
  | "scene"
  | "beat"
  | "intent"
  | "character"
  | "location"
  | "emotion"
  | "motif"
  | "music"
  | "camera"
  | "blocking"
  | "lighting"
  | "composition"
  | "editing"
  | "motion"
  | "prompt"
  | "performance";

export interface DkgNode {
  id: string; // stable: `${kind}:${key}`
  kind: NodeKind;
  key: string;
  label: string;
  properties: Record<string, unknown>;
}

export interface DkgEdge {
  source: string;
  target: string;
  kind: string;
  properties?: Record<string, unknown>;
}

export interface DirectorGraph {
  source: "heuristic";
  movieTitle: string;
  movieSlug: string;
  nodes: DkgNode[];
  edges: DkgEdge[];
  stats: {
    nodes: number;
    edges: number;
    scenes: number;
    beats: number;
    characters: number;
    locations: number;
    intents: number;
    relationships: number;
  };
  /** Co-occurrence matrix characters → used by the "click a character" view. */
  characterIndex: Record<
    string,
    {
      scenes: string[];
      emotions: string[];
      shots: string[];
      lines: number;
      relations: { kind: string; target: string }[];
    }
  >;
}

/** Kinds shown in the macro graph view (keeps the canvas readable). */
export const MACRO_KINDS: NodeKind[] = [
  "movie",
  "sequence",
  "scene",
  "beat",
  "intent",
  "character",
  "location",
  "emotion",
  "motif",
  "music",
];

/** Colors per node kind for visualization. */
export const KIND_COLORS: Record<NodeKind, string> = {
  movie: "#f59e0b",
  sequence: "#d97706",
  scene: "#38bdf8",
  beat: "#a78bfa",
  intent: "#f472b6",
  character: "#34d399",
  location: "#94a3b8",
  emotion: "#fb7185",
  motif: "#fbbf24",
  music: "#c084fc",
  camera: "#22d3ee",
  blocking: "#facc15",
  lighting: "#fde68a",
  composition: "#a3e635",
  editing: "#fb923c",
  motion: "#2dd4bf",
  prompt: "#e879f9",
  performance: "#60a5fa",
};
