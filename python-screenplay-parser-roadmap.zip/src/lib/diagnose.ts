/** Phase 1 — dataset diagnosis (dataset_report.json equivalent). */

import type { DatasetReport } from "./parser/types";
import { loadMarkdown, detectSeparator } from "./parser/markdown_loader";
import { parseScreenplay } from "./parser";

export function diagnoseFile(path: string): DatasetReport {
  const { lines, meta } = loadMarkdown(path);
  const parsed = parseScreenplay(loadMarkdown(path).raw, lines);

  const allElements = parsed.movies.flatMap((m) => m.scenes.flatMap((s) => s.elements));
  const characterCues = allElements.filter((e) => e.type === "character").length;
  const dialogueBlocks = allElements.filter((e) => e.type === "dialogue").length;
  const transitions = allElements.filter((e) => e.type === "transition").length;
  const headings = parsed.movies.flatMap((m) => m.scenes.map((s) => s.heading));
  const withTime = headings.filter((h) => /\s-\s/.test(h)).length;

  const seen = new Map<string, number>();
  for (const line of lines) {
    const s = line.trim();
    // short repeated lines (CUT TO:, SAM, ...) are normal — flag only meaningful dupes
    if (s.length > 30) seen.set(s, (seen.get(s) ?? 0) + 1);
  }
  const duplicateLines = [...seen.values()].reduce((a, c) => a + Math.max(0, c - 1), 0);

  const risks: string[] = [];
  if (meta.mixedLineEndings) risks.push("Line endings are mixed (CRLF + LF)");
  if (meta.suspiciousChars > 0) risks.push(`Suspicious characters found (${meta.suspiciousChars})`);
  if (withTime < headings.length) {
    risks.push(`Some headings lack time information (${headings.length - withTime} of ${headings.length})`);
  }
  if (characterCues > 0 && transitions > 0) {
    risks.push("Character names may be confused with transitions");
  }
  if (parsed.movies.length === 1) risks.push("Single movie detected — movie separator may be missing");
  if (duplicateLines > 0) risks.push(`Duplicate raw lines found (${duplicateLines})`);
  if (!risks.length) risks.push("No critical parsing risks detected");

  const separator = detectSeparator(lines);
  return {
    movies: parsed.movies.length,
    scenesDetected: parsed.totalScenes,
    encoding: meta.encoding,
    lineEndings: meta.lineEndings,
    separator,
    separatorConsistent: separator !== null,
    headingWithTime: withTime,
    headingWithoutTime: headings.length - withTime,
    characterCues,
    dialogueBlocks,
    transitions,
    duplicateLines,
    suspiciousChars: meta.suspiciousChars,
    fileSizeBytes: meta.fileSizeBytes,
    lineCount: meta.lineCount,
    parsingRisks: risks,
  };
}
