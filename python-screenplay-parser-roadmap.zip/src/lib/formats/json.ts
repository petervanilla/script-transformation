/** Structured/unstructured JSON → screenplay text.

If the JSON carries a recognizable screenplay structure (movies/scenes/elements
or a "text"/"script" field), reconstruct a parseable screenplay. Otherwise,
gather string leaves that look like script lines (headings, dialogue, action).
*/

import type { ParsedScreenplay } from "../parser/types";

interface Reconstructed {
  text: string;
  structured?: ParsedScreenplay;
  title?: string;
}

function looksLikeSceneHeading(s: string): boolean {
  return /^(INT|EXT|INT\.EXT|INT\/EXT|I\/E|EST)\.?\s+.+/i.test(s.trim());
}

/** Walk the JSON collecting meaningful screenplay-style lines. */
function harvestStrings(value: unknown, out: string[]): void {
  if (typeof value === "string") {
    const s = value.trim();
    if (s && (looksLikeSceneHeading(s) || /^[A-Z0-9 .,'\-()]+$/.test(s) || s.length > 0)) {
      out.push(s);
    }
  } else if (Array.isArray(value)) {
    for (const v of value) harvestStrings(v, out);
  } else if (value && typeof value === "object") {
    for (const v of Object.values(value as Record<string, unknown>)) harvestStrings(v, out);
  }
}

export function extractJson(buf: Buffer): Reconstructed {
  const parsed = JSON.parse(buf.toString("utf-8")) as unknown;

  // Case 1: already a ParsedScreenplay (our own pipeline output)
  if (
    parsed &&
    typeof parsed === "object" &&
    Array.isArray((parsed as ParsedScreenplay).movies)
  ) {
    const sc = parsed as ParsedScreenplay;
    let text = "";
    for (const movie of sc.movies) {
      text += `${movie.title.toUpperCase()}\n\n`;
      for (const scene of movie.scenes) {
        text += `${scene.heading}\n\n`;
        for (const el of scene.elements) {
          if (el.type === "scene_heading") continue;
          if (el.type === "character") text += `${el.text}\n`;
          else if (el.type === "dialogue") text += `${el.text}\n\n`;
          else if (el.type === "parenthetical") text += `${el.text}\n`;
          else if (el.type === "transition") text += `${el.text}\n\n`;
          else text += `${el.text}\n`;
        }
        text += "\n";
      }
      text += "***\n\n";
    }
    return { text: text.trim(), structured: sc, title: sc.movies[0]?.title };
  }

  // Case 2: { "text" | "script" | "screenplay": "..." }
  if (parsed && typeof parsed === "object") {
    const obj = parsed as Record<string, unknown>;
    for (const key of ["text", "script", "screenplay", "content", "body"]) {
      if (typeof obj[key] === "string") {
        return { text: (obj[key] as string).replace(/\r\n/g, "\n"), title: obj.title as string | undefined };
      }
    }
  }

  // Case 3: harvest string leaves
  const lines: string[] = [];
  harvestStrings(parsed, lines);
  return { text: lines.join("\n"), title: undefined };
}
