/** PDF → text extractor (pdf-parse v2). */

export async function extractPdf(
  buf: Buffer
): Promise<{ text: string; title?: string }> {
  const { PDFParse } = await import("pdf-parse");
  const parser = new PDFParse({ data: new Uint8Array(buf) });
  let title: string | undefined;
  try {
    const info = await parser.getInfo();
    title = (info as { info?: { Title?: string } }).info?.Title;
  } catch {
    // metadata is optional
  }
  const result = await parser.getText();
  await parser.destroy?.().catch(() => {});
  const text = (result.text || "")
    .replace(/\u00a0/g, " ")
    .replace(/-\n(\w)/g, "$1") // de-hyphenate wrapped words
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n");
  return { text, title };
}
