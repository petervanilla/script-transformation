/** Plain text / Markdown extractor. */
export function extractText(buf: Buffer): string {
  // BOM-aware decode
  let s = buf.toString("utf-8");
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1);
  return s.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
}
