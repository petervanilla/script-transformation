/** DOCX → text extractor (mammoth). */

export async function extractDocx(
  buf: Buffer
): Promise<{ text: string; title?: string }> {
  const mammoth = await import("mammoth");
  const result = await mammoth.extractRawText({ buffer: buf });
  return { text: result.value.replace(/\r\n/g, "\n").replace(/\r/g, "\n") };
}
