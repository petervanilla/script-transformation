/** Format dispatcher — turn any uploaded file into plain screenplay text. */

import { extractText } from "./text";
import { extractPdf } from "./pdf";
import { extractDocx } from "./docx";
import { extractJson } from "./json";

export type SupportedFormat = "txt" | "md" | "markdown" | "json" | "pdf" | "docx";

export const ACCEPTED_EXTENSIONS = [
  ".txt",
  ".md",
  ".markdown",
  ".json",
  ".pdf",
  ".docx",
];

export const ACCEPT_ATTR =
  ".txt,.md,.markdown,.json,.pdf,.docx,text/plain,application/json,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document";

export function detectFormat(filename: string): SupportedFormat | null {
  const ext = filename.toLowerCase().split(".").pop() ?? "";
  if (ext === "txt" || ext === "md" || ext === "markdown" || ext === "json" || ext === "pdf" || ext === "docx") {
    return ext as SupportedFormat;
  }
  return null;
}

export interface ExtractResult {
  text: string;
  format: SupportedFormat;
  title?: string;
}

export async function extractScreenplay(
  filename: string,
  buf: Buffer
): Promise<ExtractResult> {
  const format = detectFormat(filename);
  if (!format) throw new Error(`지원하지 않는 파일 형식: ${filename}`);

  if (format === "txt" || format === "md" || format === "markdown") {
    return { text: extractText(buf), format };
  }
  if (format === "json") {
    const r = extractJson(buf);
    return { text: r.text, format, title: r.title };
  }
  if (format === "pdf") {
    const r = await extractPdf(buf);
    return { text: r.text, format, title: r.title };
  }
  if (format === "docx") {
    const r = await extractDocx(buf);
    return { text: r.text, format, title: r.title };
  }
  throw new Error(`지원하지 않는 파일 형식: ${format}`);
}

export { extractText };
