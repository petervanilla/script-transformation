/** Phase 7 preview — rule-based Shot Planner.

Scene/Beat accuracy is the gate (Phase 4–6). Once beats are stable, this
stage derives camera + blocking + motion candidates that a director can
approve/revise in the review screen. Still deterministic — no invented
facts; every decision is traceable to a beat property.
*/

import { strongestEmotion } from "./emotion";
import type { Beat, ShotPlan } from "./types";

function inferSubject(beat: Beat): string {
  if (beat.speakers.length) return beat.speakers.join(" + ");
  const m = beat.action.match(/\b(SAM|LUCY|GEORGE|RACHEL|RITA|ANNIE|JACK|JUDGE|DOCTOR|MAYA|MAN|WAITRESS)\b/i);
  return m ? m[1].toUpperCase() : "scene environment";
}

function inferIntent(beat: Beat, text: string): string {
  if (/montage/i.test(text)) return "일상의 리듬을 시각적 반복으로 전달한다";
  if (/count|practice|sorts|lines up/i.test(text)) return "반복 행동으로 인물의 성격을 드러낸다";
  const emotion = strongestEmotion(text);
  if (emotion === "분노") return "갈등의 고조를 표정과 자세로 전달한다";
  if (emotion === "슬픔") return "취약함을 클로즈업으로 드러낸다";
  if (emotion === "애정") return "두 인물의 유대를 하나의 프레임에 담는다";
  if (emotion === "긴장") return "불안의 기미를 미세한 움직임으로 암시한다";
  return "행동과 대화의 의도를 명확히 전달한다";
}

function inferMotion(beat: Beat): { actorAction: string; tempo: string } {
  const action = beat.action.replace(/\s+/g, " ").trim();
  let actorAction = action.length > 0 ? action : beat.objective;
  if (actorAction.length > 90) actorAction = `${actorAction.slice(0, 90)}…`;
  const emotion = strongestEmotion(`${beat.action} ${beat.evidence.join(" ")}`);
  let tempo = "calm and neutral";
  if (emotion === "분노") tempo = "sharp, clipped, escalating";
  else if (emotion === "긴장") tempo = "slow, guarded, tense";
  else if (emotion === "슬픔") tempo = "slow, heavy, deliberate";
  else if (emotion === "애정") tempo = "gentle, warm, unhurried";
  else if (/montage/i.test(beat.evidence.join(" "))) tempo = "rhythmic, music-driven";
  return { actorAction, tempo };
}

export function planShot(beat: Beat, shotCode: string): ShotPlan {
  const text = [...beat.evidence, beat.action, beat.objective].join(" ").toLowerCase();
  const emotion = strongestEmotion(text);
  const subject = inferSubject(beat);
  const isMontage = /montage/i.test(text);

  let shotSize = "medium shot";
  let movement = "static (locked-off)";
  let lens = "50mm";
  let height = "eye level";

  if (isMontage) {
    shotSize = "wide shot";
    movement = "lateral tracking";
    lens = "35mm";
    height = "chest height";
  } else if (emotion === "분노") {
    shotSize = "medium close-up";
    movement = "handheld micro-movement";
    lens = "35mm";
    height = "low angle";
  } else if (emotion === "슬픔" || emotion === "긴장") {
    shotSize = "close-up";
    movement = "slow push-in";
    lens = "85mm";
    height = "eye level";
  } else if (emotion === "애정") {
    shotSize = "medium two-shot";
    movement = "slow dolly in";
    lens = "50mm";
    height = "eye level";
  } else if (/\b(run|runs|rush|walks|paces)\b/i.test(text)) {
    shotSize = "medium shot";
    movement = "tracking shot";
    lens = "40mm";
    height = "eye level";
  }

  const motion = inferMotion(beat);
  const intent = inferIntent(beat, text);
  const prompt = `${shotSize} of ${subject}, ${movement}, ${lens} lens, ${height}. ` +
    `${motion.actorAction}. Tempo: ${motion.tempo}. Cinematic natural light, filmic color grade.`;

  return {
    shotCode,
    intent,
    subject,
    shotSize,
    camera: { movement, lens, height },
    motion,
    prompt,
  };
}

export function planShots(beats: Beat[], sceneCode: string): ShotPlan[] {
  return beats.map((beat, i) => planShot(beat, `${sceneCode}_SH${String(i + 1).padStart(3, "0")}`));
}
