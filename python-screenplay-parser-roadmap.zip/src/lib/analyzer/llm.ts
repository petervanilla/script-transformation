/** Optional LLM beat analyzer — Phase 3/4 with a strict JSON schema.

The heuristic engine (beat_analyzer.ts) is the always-available default.
When OPENAI_API_KEY is present, this client asks the model to fill the
exact same Beat schema, requiring `evidence` (원문 근거) for every claim
and a `confidence` score — mirroring the Python phase-3 design.
*/

import type { Scene } from "../parser/types";
import type { Beat } from "./types";

const SYSTEM_PROMPT = `You are a screenplay beat analyst. Analyze the given scene and split it into beats.

Return ONLY a JSON object with this exact schema:
{
  "scene_function": string,
  "beats": [
    {
      "start_text": string,        // first words of the beat from the source
      "end_text": string,          // last words of the beat from the source
      "objective": string,         // character goal in Korean
      "action": string,            // what physically happens
      "emotion_before": string,    // Korean emotion label
      "emotion_after": string,     // Korean emotion label
      "conflict": string | null,
      "relationship_change": string,
      "evidence": [string],        // verbatim source quotes justifying your judgment
      "confidence": number         // 0..1
    }
  ]
}

Rules:
- Never invent facts that are not in the source text.
- Every judgment must be backed by evidence quoted from the scene.
- Beat boundaries: transitions, speaker changes, action-paragraph breaks.
- Write objective/emotion/conflict in Korean.`;

function firstDefined<T>(...values: (T | undefined)[]): T | undefined {
  return values.find((v) => v !== undefined && v !== null && v !== "");
}

export async function analyzeWithLLM(
  scene: Scene,
  apiKey: string,
  model = "gpt-4o-mini"
): Promise<{ beats: Beat[]; sceneFunction: string; model: string }> {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      temperature: 0.2,
      response_format: { type: "json_object" },
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: `Scene heading: ${scene.heading}\n\nScreenplay text:\n${scene.elements
            .filter((e) => e.type !== "scene_heading")
            .map((e) => e.text)
            .join("\n")}`,
        },
      ],
    }),
  });

  if (!res.ok) {
    throw new Error(`LLM request failed: ${res.status} ${await res.text()}`);
  }

  const payload = (await res.json()) as {
    choices: { message: { content: string } }[];
  };
  const content = payload.choices?.[0]?.message?.content ?? "{}";
  const raw = JSON.parse(content) as {
    scene_function?: string;
    beats?: Record<string, unknown>[];
  };

  const beats: Beat[] = (raw.beats ?? []).map((b, i) => ({
    index: i + 1,
    startText: String(firstDefined(b.start_text, b.startText) ?? ""),
    endText: String(firstDefined(b.end_text, b.endText) ?? ""),
    speakers: Array.isArray(b.speakers) ? (b.speakers as string[]) : [],
    objective: String(firstDefined(b.objective) ?? ""),
    action: String(firstDefined(b.action) ?? ""),
    emotionBefore: String(firstDefined(b.emotion_before, b.emotionBefore) ?? "중립"),
    emotionAfter: String(firstDefined(b.emotion_after, b.emotionAfter) ?? "중립"),
    conflict: (firstDefined(b.conflict) as string | null) ?? null,
    relationshipChange: String(firstDefined(b.relationship_change, b.relationshipChange) ?? ""),
    evidence: Array.isArray(b.evidence) ? (b.evidence as string[]).map(String) : [],
    confidence: Math.min(1, Math.max(0, Number(b.confidence ?? 0.5))),
  }));

  if (!beats.length) throw new Error("LLM returned no beats");
  return { beats, sceneFunction: String(raw.scene_function ?? ""), model };
}
