/** Phase 3 — Beat analysis schema (strict JSON contract). */

export interface Beat {
  index: number;
  startText: string;
  endText: string;
  speakers: string[];
  objective: string;
  action: string;
  emotionBefore: string;
  emotionAfter: string;
  conflict: string | null;
  relationshipChange: string;
  /** 원문 근거 — why the AI/heuristic decided this way. */
  evidence: string[];
  confidence: number;
}

/** Phase 7 preview — Shot plan derived from a beat. */
export interface ShotPlan {
  shotCode: string; // SC001_SH001
  intent: string;
  subject: string;
  shotSize: string;
  camera: { movement: string; lens: string; height: string };
  motion: { actorAction: string; tempo: string };
  prompt: string;
}

export interface SceneAnalysis {
  sceneCode: string;
  sceneFunction: string;
  source: "heuristic" | "llm";
  model: string | null;
  beats: Beat[];
  shots: ShotPlan[];
}
