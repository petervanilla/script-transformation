/** Phase 3–4 — deterministic beat analyzer (heuristic engine).

The LLM can later enrich/override these fields (see llm.ts), but the
heuristic engine guarantees a stable, explainable baseline that never
invents facts absent from the source text.
*/

import type { Scene, ScreenplayElement } from "../parser/types";
import { detectEmotions, strongestEmotion } from "./emotion";
import type { Beat, SceneAnalysis } from "./types";

const REFUSAL_RE = /\b(no|can't|cannot|won't|don't|never|stop|leave)\b/i;
const CONFLICT_RE = /\b(but|however|against|fight|argue|refuse|demand|threaten|scare)\b/i;
const RELATIONSHIP_RE: { re: RegExp; change: string }[] = [
  { re: /\b(hug|hugs|holding|hold|kiss|kisses|embrace|wrap)\b/i, change: "친밀감이 깊어진다" },
  { re: /\b(walk away|leaves|leave|turn away|boards|gone)\b/i, change: "거리감 또는 이별의 기미가 보인다" },
  { re: /\b(apolog|forgive|thank|thanks|proud)\b/i, change: "화해·감사·자부심의 흐름이 생긴다" },
  { re: /\b(tremble|trembling|shake|shakes|stare|stares|freeze|tenses)\b/i, change: "긴장·불안이 관계 위에 드리운다" },
];

function truncate(s: string, n: number): string {
  const t = s.replace(/\s+/g, " ").trim();
  return t.length > n ? `${t.slice(0, n)}…` : t;
}

/** Split a scene's elements into beat-sized units.

Boundary rules (explainable, deterministic):
* a transition ends the current beat
* an action paragraph appearing AFTER dialogue starts a new beat
  (dialogue-only back-and-forth stays one beat; montage stays one beat)
* a long action paragraph (>160 chars) is itself a new beat
* montage blocks are never split internally
*/
export function splitBeats(elements: ScreenplayElement[]): ScreenplayElement[][] {
  const beats: ScreenplayElement[][] = [];
  let current: ScreenplayElement[] = [];
  let currentHasDialogue = false;
  let inMontage = false;

  const pushCurrent = () => {
    if (current.length) {
      beats.push(current);
      current = [];
      currentHasDialogue = false;
    }
  };

  for (const el of elements) {
    if (el.type === "transition") {
      // transitions attach to the END of the previous beat; leading ones are dropped
      if (current.length) {
        current.push(el);
        pushCurrent();
      }
      continue;
    }
    if (el.type === "montage") {
      pushCurrent();
      current = [el];
      inMontage = true;
      continue;
    }
    if (el.type === "end_montage") {
      current.push(el);
      pushCurrent();
      inMontage = false;
      continue;
    }
    if (el.type === "dialogue" || el.type === "parenthetical") {
      currentHasDialogue = true;
      current.push(el);
      continue;
    }
    if (el.type === "action" && !inMontage) {
      if (current.length && currentHasDialogue) {
        // action after dialogue = new unit of action
        pushCurrent();
        current = [el];
        continue;
      }
      if (el.text.length > 160) {
        pushCurrent();
        current = [el];
        continue;
      }
      current.push(el);
      continue;
    }
    current.push(el);
  }
  pushCurrent();
  return beats;
}

function inferObjective(speakers: string[], dialogues: ScreenplayElement[], allText: string): string {
  const d = dialogues.map((x) => x.text).join(" ").trim();
  const last = d.slice(-1);
  if (!speakers.length) return "행동·화면 묘사를 통해 분위기와 상태를 전달한다";
  const lead = speakers[0];
  if (/please/.test(d)) return `${lead}는 간청하며 상대의 마음을 움직이려 한다`;
  if (/sorry|forgive/.test(d)) return `${lead}는 사과하며 관계를 회복하려 한다`;
  if (/\bhelp\b/.test(d)) return `${lead}는 도움을 구하거나 지지를 요청한다`;
  if (/thank/.test(d)) return `${lead}는 감사를 전하며 관계를 다진다`;
  if (/remember|practice|forget/.test(d)) return `${lead}는 기억과 반복 행동으로 자신을 지켜낸다`;
  if (last === "?") return `${lead}는 질문하며 상대의 진심을 확인한다`;
  if (last === "!") return `${lead}는 강한 어조로 자신의 입장을 주장한다`;
  if (REFUSAL_RE.test(d)) return `${lead}는 거절하며 경계를 세운다`;
  if (speakers.length >= 2) return `${speakers.join("와 ")}는 대화를 주고받으며 입장을 교환한다`;
  return `${lead}는 상황을 설명하거나 의사를 전달한다`;
}

function inferAction(elements: ScreenplayElement[]): string {
  const actions = elements.filter((e) => e.type === "action" || e.type === "montage");
  const dialogues = elements.filter((e) => e.type === "dialogue");
  const speakers = elements.filter((e) => e.type === "character").map((e) => e.character);
  if (actions.length) return truncate(actions[0].text, 72);
  if (dialogues.length) return `${[...new Set(speakers)].join(", ")}의 대화가 이어진다`;
  return "화면의 상태가 묘사된다";
}

function evidenceFor(elements: ScreenplayElement[]): string[] {
  const lines: string[] = [];
  const push = (s: string) => {
    if (lines.length < 5) lines.push(truncate(s, 110));
  };
  for (const el of elements) {
    if (el.type === "dialogue") push(`[대화 ${el.character ?? ""}] ${el.text}`);
    else if (el.type === "action") push(`[행동] ${el.text}`);
    else if (el.type === "transition") push(`[전환] ${el.text}`);
  }
  return lines;
}

function confidenceFor(elements: ScreenplayElement[], conflict: boolean): number {
  let c = 0.55; // heuristic baseline
  const dialogues = elements.filter((e) => e.type === "dialogue").length;
  c += Math.min(dialogues, 3) * 0.05;
  if (conflict) c += 0.05;
  if (elements.some((e) => detectEmotions(e.text).length)) c += 0.05;
  return Math.round(Math.min(c, 0.85) * 100) / 100;
}

function analyzeBeat(elements: ScreenplayElement[], index: number): Beat {
  const dialogues = elements.filter((e) => e.type === "dialogue");
  const speakers = [...new Set(elements.filter((e) => e.type === "character").map((e) => e.character!))];
  const allText = elements.map((e) => e.text).join(" ");
  const dialogueText = dialogues.map((e) => e.text).join(" ");

  const firstEmotion = strongestEmotion(elements.slice(0, Math.max(1, Math.floor(elements.length / 2))).map((e) => e.text).join(" "));
  const lastEmotion = strongestEmotion(elements.slice(Math.floor(elements.length / 2)).map((e) => e.text).join(" "));

  const conflict = speakers.length >= 2 && (REFUSAL_RE.test(dialogueText) || CONFLICT_RE.test(dialogueText));

  let relationshipChange = "뚜렷한 관계 변화 없음";
  for (const { re, change } of RELATIONSHIP_RE) {
    if (re.test(allText)) {
      relationshipChange = change;
      break;
    }
  }

  return {
    index,
    startText: truncate(elements[0]?.text ?? "", 80),
    endText: truncate(elements[elements.length - 1]?.text ?? "", 80),
    speakers,
    objective: inferObjective(speakers, dialogues, allText),
    action: inferAction(elements),
    emotionBefore: firstEmotion ?? "중립",
    emotionAfter: lastEmotion ?? "중립",
    conflict: conflict ? "상대의 요구와 인물의 의지가 충돌한다" : null,
    relationshipChange,
    evidence: evidenceFor(elements),
    confidence: confidenceFor(elements, conflict),
  };
}

export function inferSceneFunction(scene: Scene): string {
  const types = scene.elements.map((e) => e.type);
  const characters = new Set(scene.elements.filter((e) => e.type === "character").map((e) => e.character));
  const dialogueCount = types.filter((t) => t === "dialogue").length;
  const actionCount = types.filter((t) => t === "action").length;
  const extensions = scene.elements.filter((e) => e.type === "character").map((e) => e.extension);
  if (types.includes("montage")) return "몽타주 — 시간과 행동을 압축해 일상의 리듬을 전달";
  if (extensions.includes("V.O.")) return "V.O. 내레이션 — 내면의 목소리로 주관을 전달";
  if (extensions.includes("O.S.")) return "O.S. 사운드 — 화면 밖의 소리로 긴장을 유발";
  if (characters.size >= 3) return "다인물 장면 — 여러 인물의 시선이 교차한다";
  if (dialogueCount > actionCount * 2 && dialogueCount > 3) return "대화 중심 장면 — 관계와 갈등이 말로 표출된다";
  if (actionCount > dialogueCount) return "액션 중심 장면 — 행동이 서사를 전달한다";
  return "혼합 장면 — 행동과 대화가 균형을 이룬다";
}

export function analyzeScene(scene: Scene): SceneAnalysis {
  const beats = splitBeats(scene.elements).map((els, i) => analyzeBeat(els, i + 1));
  return {
    sceneCode: scene.code,
    sceneFunction: inferSceneFunction(scene),
    source: "heuristic",
    model: "rule-based-emotion-lexicon-v1",
    beats,
    shots: [],
  };
}
