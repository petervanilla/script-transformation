/** Emotion lexicon — deterministic keyword → emotion mapping (Korean labels). */

export const EMOTION_LEXICON: Record<string, string> = {
  // 슬픔
  cry: "슬픔", cries: "슬픔", crying: "슬픔", sob: "슬픔", sobs: "슬픔", sobbing: "슬픔",
  tear: "슬픔", tears: "슬픔", wept: "슬픔",
  // 기쁨
  smile: "기쁨", smiles: "기쁨", smiling: "기쁨", laugh: "기쁨", laughs: "기쁨",
  laughing: "기쁨", beam: "기쁨", beaming: "기쁨", joy: "기쁨", giggle: "기쁨",
  // 분노
  shout: "분노", shouts: "분노", shouting: "분노", yell: "분노", yells: "분노",
  slam: "분노", slams: "분노", angry: "분노",
  // 긴장
  whisper: "긴장", whispers: "긴장", trembling: "긴장", tremble: "긴장", trembles: "긴장",
  shake: "긴장", shakes: "긴장", shaking: "긴장", freeze: "긴장", freezes: "긴장",
  tense: "긴장", tenses: "긴장", knuckles: "긴장",
  // 애정
  hug: "애정", hugs: "애정", holding: "애정", hold: "애정", kiss: "애정", kisses: "애정",
  wrap: "애정", wraps: "애정", embrace: "애정",
  // 초조
  pace: "초조", paces: "초조", pacing: "초조", fidget: "초조", fidgets: "초조",
  // 경계
  stare: "경계", stares: "경계", frozen: "경계", guard: "경계", guarded: "경계",
  // 안도
  relax: "안도", relaxes: "안도", sigh: "안도", sighs: "안도", relieved: "안도",
  exhale: "안도", exhaling: "안도",
  // 긴급
  run: "긴급", runs: "긴급", rush: "긴급", rushes: "긴급", hurry: "긴급",
};

export interface EmotionHit {
  emotion: string;
  keyword: string;
}

/** Return matched emotions in order of first appearance in the text. */
export function detectEmotions(text: string): EmotionHit[] {
  const lower = text.toLowerCase();
  const hits: EmotionHit[] = [];
  const seen = new Set<string>();
  for (const [keyword, emotion] of Object.entries(EMOTION_LEXICON)) {
    if (lower.includes(keyword) && !seen.has(emotion)) {
      seen.add(emotion);
      hits.push({ emotion, keyword });
    }
  }
  return hits;
}

export function strongestEmotion(text: string): string | null {
  const hits = detectEmotions(text);
  return hits.length ? hits[0].emotion : null;
}
