/** markdown_loader — reads the raw source file (Phase 1 file-state checks). */

import * as fs from "fs";
import type { DatasetReport } from "./types";

const SEPARATORS: { re: RegExp; label: string }[] = [
  { re: /^\*{3,}\s*$/, label: "***" },
  { re: /^-{3,}\s*$/, label: "---" },
  { re: /^={3,}\s*$/, label: "===" },
  { re: /^_{3,}\s*$/, label: "___" },
];

export function isSeparatorLine(line: string): boolean {
  const s = line.trim();
  return SEPARATORS.some(({ re }) => re.test(s));
}

export function detectSeparator(lines: string[]): string | null {
  for (const line of lines) {
    const s = line.trim();
    for (const { re, label } of SEPARATORS) {
      if (re.test(s)) return label;
    }
  }
  return null;
}

export interface LoadedMarkdown {
  raw: string;
  lines: string[];
  meta: {
    fileSizeBytes: number;
    encoding: string;
    lineEndings: string;
    mixedLineEndings: boolean;
    suspiciousChars: number;
    lineCount: number;
  };
}

export function loadMarkdown(path: string): LoadedMarkdown {
  const data = fs.readFileSync(path);
  const meta: LoadedMarkdown["meta"] = { fileSizeBytes: data.length } as LoadedMarkdown["meta"];

  // BOM-aware encoding detection
  let encoding = "utf-8";
  if (data[0] === 0xef && data[1] === 0xbb && data[2] === 0xbf) encoding = "utf-8-sig";
  else if (data[0] === 0xff && data[1] === 0xfe) encoding = "utf-16-le";
  else if (data[0] === 0xfe && data[1] === 0xff) encoding = "utf-16-be";
  meta.encoding = encoding;

  let text = data.toString("utf-8");
  if (encoding === "utf-8-sig") text = text.replace(/^\uFEFF/, "");

  const crlf = (text.match(/\r\n/g) ?? []).length;
  const lf = (text.match(/\n/g) ?? []).length - crlf;
  meta.lineEndings = crlf > lf ? "CRLF" : lf > 0 ? "LF" : "none";
  meta.mixedLineEndings = crlf > 0 && lf > 0;

  text = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const lines = text.split("\n");

  let suspicious = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0) ?? 0;
    if (ch === "\uFFFD" || (code >= 0xe000 && code <= 0xf8ff)) suspicious += 1;
  }
  meta.suspiciousChars = suspicious;
  meta.lineCount = lines.length;
  return { raw: text, lines, meta };
}

/** Split raw lines into movie chunks using separator lines. */
export function splitMovies(
  lines: string[]
): { titleHint: string; startLine: number; lines: string[] }[] {
  const chunks: { titleHint: string; startLine: number; lines: string[] }[] = [];
  let current: string[] = [];
  let currentStart = 1;
  let titleHint = "";
  lines.forEach((line, idx) => {
    const lineNo = idx + 1;
    if (isSeparatorLine(line)) {
      if (current.length) chunks.push({ titleHint, startLine: currentStart, lines: current });
      current = [];
      currentStart = lineNo + 1;
      titleHint = "";
    } else {
      if (!current.length && line.trim()) titleHint = line.trim();
      current.push(line);
    }
  });
  if (current.length) chunks.push({ titleHint, startLine: currentStart, lines: current });
  return chunks;
}

export { type DatasetReport };
