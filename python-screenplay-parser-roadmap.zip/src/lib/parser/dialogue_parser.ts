/** dialogue_parser — character cues, parentheticals and dialogue blocks. */

const NAME_CHARS = "A-Z0-9 .'\\-";
const CUE_RE = new RegExp(
  `([A-Z][${NAME_CHARS}]{0,28}?)\\s*(?:\\(([A-Z0-9 .'\\-]+)\\))?\\s*$`
);

export function isParenthetical(line: string): boolean {
  const s = line.trim();
  return s.startsWith("(") && s.endsWith(")") && s.length > 2;
}

/** Return { name, extension } if the line looks like a character cue. */
export function parseCharacterCue(
  line: string
): { name: string; extension: string | null } | null {
  const s = line.trim();
  if (!s || s.length > 48) return null;
  // A cue never contains an internal colon (TITLE CARD: ... is action).
  if (s.includes(":") && !/\([^)]+\)\s*$/.test(s)) return null;
  const m = CUE_RE.exec(s);
  if (!m) return null;
  const name = m[1].trim();
  const extension = m[2] ?? null;
  if (!name || name.length > 24) return null;
  // All-caps sanity check: no lowercase letters in the name.
  if (name !== name.toUpperCase() || !/[A-Z]/.test(name)) return null;
  return { name, extension };
}
