/** Shared types for the screenplay pipeline (mirrors python/screenplay_parser). */

export type ElementType =
  | "scene_heading"
  | "action"
  | "character"
  | "dialogue"
  | "parenthetical"
  | "transition"
  | "montage"
  | "end_montage"
  | "end_marker"
  | "blank";

export interface ScreenplayElement {
  type: ElementType;
  text: string;
  line: number;
  character?: string | null;
  extension?: string | null; // V.O., O.S., CONT'D ...
}

export interface Scene {
  index: number;
  code: string; // SC001, SC002 ...
  heading: string;
  location: string | null;
  interior: boolean | null;
  timeOfDay: string | null;
  startLine: number;
  endLine: number;
  rawText: string;
  elements: ScreenplayElement[];
}

export interface Movie {
  title: string;
  slug: string;
  scenes: Scene[];
  characters: string[];
  characterLines: Record<string, number>;
  lineCount: number;
}

export interface ParsedScreenplay {
  movies: Movie[];
  totalScenes: number;
  totalLines: number;
}

/** Phase 1 output — file state diagnosis. */
export interface DatasetReport {
  movies: number;
  scenesDetected: number;
  encoding: string;
  lineEndings: string;
  separator: string | null;
  separatorConsistent: boolean;
  headingWithTime: number;
  headingWithoutTime: number;
  characterCues: number;
  dialogueBlocks: number;
  transitions: number;
  duplicateLines: number;
  suspiciousChars: number;
  fileSizeBytes: number;
  lineCount: number;
  parsingRisks: string[];
}
