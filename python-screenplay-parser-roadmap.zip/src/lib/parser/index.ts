/** Pipeline entry — markdown → movies → scenes → elements (Phase 2). */

import type { Movie, ParsedScreenplay, ScreenplayElement } from "./types";
import { loadMarkdown, splitMovies } from "./markdown_loader";
import { buildScenes, classifyLine, isSceneHeading } from "./scene_parser";

export function slugify(title: string): string {
  const s = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
  return s || "untitled";
}

export function parseScreenplay(raw: string, lines: string[]): ParsedScreenplay {
  const chunks = splitMovies(lines);
  const movies: Movie[] = [];

  for (const chunk of chunks) {
    // --- split header (title/credits) from the body ---
    let headerEnd = 0;
    for (let i = 0; i < chunk.lines.length; i++) {
      if (isSceneHeading(chunk.lines[i])) {
        headerEnd = i;
        break;
      }
    }
    const header = chunk.lines.slice(0, headerEnd);
    const body = chunk.lines.slice(headerEnd);

    const title = header.find((l) => l.trim())?.trim() ?? "UNTITLED";
    const preamble: ScreenplayElement[] = [];
    header.forEach((line, i) => {
      const el = classifyLine(line, chunk.startLine + i);
      // keep only filmic markers (FADE IN: etc.) — drop title, credits, notes
      if (!["transition", "montage", "end_montage", "end_marker"].includes(el.type)) return;
      preamble.push(el);
    });

    const scenes = buildScenes(body, chunk.startLine + headerEnd);
    if (scenes.length && preamble.length) {
      scenes[0].elements = [...preamble, ...scenes[0].elements];
      scenes[0].startLine = Math.min(scenes[0].startLine, preamble[0].line);
    }

    const characterLines: Record<string, number> = {};
    for (const sc of scenes) {
      for (const el of sc.elements) {
        if (el.type === "character" && el.character) {
          characterLines[el.character] = (characterLines[el.character] ?? 0) + 1;
        }
      }
    }

    movies.push({
      title,
      slug: slugify(title),
      scenes,
      characters: Object.keys(characterLines).sort(),
      characterLines,
      lineCount: chunk.lines.length,
    });
  }

  return {
    movies,
    totalScenes: movies.reduce((acc, m) => acc + m.scenes.length, 0),
    totalLines: lines.length,
  };
}

export function parseScreenplayFile(path: string): ParsedScreenplay {
  const { raw, lines } = loadMarkdown(path);
  return parseScreenplay(raw, lines);
}

export * from "./types";
