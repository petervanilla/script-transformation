/** transition_parser — transitions, montage blocks and end markers. */

const TRANSITION_RE =
  /^(FADE IN|FADE OUT|CUT TO|DISSOLVE TO|SMASH CUT TO|MATCH CUT TO|WIPE TO|IRIS|HARD CUT TO|JUMP CUT TO|FADE TO BLACK)[.:]?\s*$/i;

export function isTransition(line: string): boolean {
  return TRANSITION_RE.test(line.trim());
}

export function isMontage(line: string): boolean {
  return /^MONTAGE\b/i.test(line.trim());
}

export function isEndMontage(line: string): boolean {
  return /^END MONTAGE\b/i.test(line.trim());
}

export function isEndMarker(line: string): boolean {
  return line.trim().toUpperCase() === "THE END";
}
