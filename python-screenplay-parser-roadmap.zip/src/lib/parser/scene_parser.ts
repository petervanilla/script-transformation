/** scene_parser — detects scene headings and groups lines into Scene objects. */

import type { Scene, ScreenplayElement } from "./types";
import { isParenthetical, parseCharacterCue } from "./dialogue_parser";
import { isEndMarker, isEndMontage, isMontage, isTransition } from "./transition_parser";

const SCENE_HEADING_RE = /^(INT|EXT|INT\.EXT|INT\/EXT|I\/E|EST)\.?\s+(.+)$/i;

export function isSceneHeading(line: string): boolean {
  const s = line.trim();
  if (!s) return false;
  return SCENE_HEADING_RE.test(s.replace(/^#+\s*/, ""));
}

export function parseHeading(
  heading: string
): { location: string | null; interior: boolean | null; timeOfDay: string | null } {
  const h = heading.trim().replace(/^#+\s*/, "");
  const m = SCENE_HEADING_RE.exec(h);
  let interior: boolean | null = null;
  let rest = h;
  if (m) {
    const prefix = m[1].toUpperCase();
    interior = prefix.startsWith("INT") || ["I/E", "INT/EXT", "INT.EXT"].includes(prefix);
    rest = m[2].trim();
  }
  const parts = rest.split(/\s+-\s+/);
  if (parts.length >= 2) {
    return { location: parts[0].trim(), interior, timeOfDay: parts[parts.length - 1].trim() };
  }
  return { location: rest.trim(), interior, timeOfDay: null };
}

export function classifyLine(
  line: string,
  lineNo: number,
  inMontage = false
): ScreenplayElement {
  const stripped = line.trim();
  if (!stripped) return { type: "blank", text: "", line: lineNo };
  if (isSceneHeading(stripped)) return { type: "scene_heading", text: stripped, line: lineNo };
  if (inMontage) {
    if (isEndMontage(stripped)) return { type: "end_montage", text: stripped, line: lineNo };
    return { type: "action", text: stripped, line: lineNo };
  }
  if (isMontage(stripped)) return { type: "montage", text: stripped, line: lineNo };
  if (isTransition(stripped)) return { type: "transition", text: stripped, line: lineNo };
  if (isEndMarker(stripped)) return { type: "end_marker", text: stripped, line: lineNo };
  if (isParenthetical(stripped)) return { type: "parenthetical", text: stripped, line: lineNo };
  const cue = parseCharacterCue(stripped);
  if (cue) {
    return {
      type: "character",
      text: stripped,
      line: lineNo,
      character: cue.name,
      extension: cue.extension,
    };
  }
  return { type: "action", text: stripped, line: lineNo };
}

/** After a character cue, fold parentheticals/actions into a dialogue block. */
export function groupDialogue(elements: ScreenplayElement[]): ScreenplayElement[] {
  const out: ScreenplayElement[] = [];
  let i = 0;
  while (i < elements.length) {
    const el = elements[i];
    out.push(el);
    if (el.type === "character") {
      let j = i + 1;
      while (j < elements.length) {
        const nxt = elements[j];
        if (nxt.type !== "parenthetical" && nxt.type !== "action") break;
        out.push(
          nxt.type === "parenthetical"
            ? nxt
            : { type: "dialogue", text: nxt.text, line: nxt.line }
        );
        j += 1;
      }
      i = j;
      continue;
    }
    i += 1;
  }
  return out;
}

export function buildScenes(lines: string[], baseLine = 0): Scene[] {
  const scenes: Scene[] = [];
  let headingLine: number | null = null;
  let headingText: string | null = null;
  let elements: ScreenplayElement[] = [];
  let inMontage = false;

  const flush = (lastLine: number) => {
    if (headingText === null || headingLine === null) return;
    const grouped = groupDialogue(elements).filter((e) => e.type !== "blank");
    const start = headingLine;
    const end = lastLine;
    const raw = lines.slice(start - 1 - baseLine, end - baseLine).join("\n");
    const { location, interior, timeOfDay } = parseHeading(headingText);
    scenes.push({
      index: scenes.length + 1,
      code: `SC${String(scenes.length + 1).padStart(3, "0")}`,
      heading: headingText,
      location,
      interior,
      timeOfDay,
      startLine: start,
      endLine: end,
      rawText: raw,
      elements: grouped,
    });
    headingLine = null;
    headingText = null;
    elements = [];
  };

  lines.forEach((line, idx) => {
    const el = classifyLine(line, baseLine + idx + 1, inMontage);
    if (el.type === "montage") inMontage = true;
    else if (el.type === "end_montage") inMontage = false;
    if (el.type === "scene_heading") {
      flush(baseLine + idx);
      headingLine = baseLine + idx + 1;
      headingText = el.text;
      elements = [];
    } else if (headingText === null) {
      // title/credit region — handled by parseScreenplay preamble logic
    } else {
      elements.push(el);
    }
  });
  flush(baseLine + lines.length);
  return scenes;
}
