import {
  boolean,
  integer,
  jsonb,
  pgTable,
  real,
  text,
  timestamp,
  uuid,
  index,
} from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";

/** Raw source movies (one row per movie found in data/movies.md). */
export const movies = pgTable("movies", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  sourceFile: text("source_file").notNull(),
  sceneCount: integer("scene_count").default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
});

export const scenes = pgTable(
  "scenes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    movieId: uuid("movie_id")
      .notNull()
      .references(() => movies.id, { onDelete: "cascade" }),
    sceneIndex: integer("scene_index").notNull(),
    code: text("code").notNull(), // SC001
    heading: text("heading").notNull(),
    location: text("location"),
    interior: boolean("interior"),
    timeOfDay: text("time_of_day"),
    startLine: integer("start_line"),
    endLine: integer("end_line"),
    rawText: text("raw_text"),
    elements: jsonb("elements").$type<
      {
        type: string;
        text: string;
        line: number;
        character?: string | null;
        extension?: string | null;
      }[]
    >(),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  },
  (t) => [index("scenes_movie_idx").on(t.movieId)]
);

/** Beat analysis results (saved per scene, reviewable). */
export const beats = pgTable(
  "beats",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    sceneId: uuid("scene_id")
      .notNull()
      .references(() => scenes.id, { onDelete: "cascade" }),
    beatIndex: integer("beat_index").notNull(),
    startText: text("start_text"),
    endText: text("end_text"),
    speakers: jsonb("speakers").$type<string[]>(),
    objective: text("objective"),
    action: text("action"),
    emotionBefore: text("emotion_before"),
    emotionAfter: text("emotion_after"),
    conflict: text("conflict"),
    relationshipChange: text("relationship_change"),
    evidence: jsonb("evidence").$type<string[]>(),
    confidence: real("confidence"),
    analysisSource: text("analysis_source"),
    status: text("status").default("pending"), // pending | approved | revised
    notes: text("notes"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow(),
  },
  (t) => [index("beats_scene_idx").on(t.sceneId)]
);

/** Phase 7 preview — shot plans derived from beats. */
export const shots = pgTable(
  "shots",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    beatId: uuid("beat_id")
      .notNull()
      .references(() => beats.id, { onDelete: "cascade" }),
    shotCode: text("shot_code").notNull(),
    intent: text("intent"),
    subject: text("subject"),
    shotSize: text("shot_size"),
    camera: jsonb("camera").$type<{ movement: string; lens: string; height: string }>(),
    motion: jsonb("motion").$type<{ actorAction: string; tempo: string }>(),
    prompt: text("prompt"),
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  },
  (t) => [index("shots_beat_idx").on(t.beatId)]
);

/** Uploaded screenplay sources (JSON / Word / txt / PDF). */
export const sources = pgTable("sources", {
  id: uuid("id").defaultRandom().primaryKey(),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  format: text("format").notNull(), // txt | md | json | pdf | docx
  sizeBytes: integer("size_bytes").notNull(),
  mime: text("mime"),
  title: text("title"),
  charCount: integer("char_count").default(0),
  movieCount: integer("movie_count").default(0),
  sceneCount: integer("scene_count").default(0),
  status: text("status").default("uploaded"), // uploaded | parsed | error
  error: text("error"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

/** Director Knowledge Graph — property-graph model in PostgreSQL. */
export const graphMovies = pgTable("graph_movies", {
  id: uuid("id").defaultRandom().primaryKey(),
  sourceId: uuid("source_id").references(() => sources.id, { onDelete: "cascade" }),
  title: text("title").notNull(),
  slug: text("slug").notNull(),
  graph: jsonb("graph").$type<unknown>(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

export const schemaVersion = sql<string>`select 'ok'`;
