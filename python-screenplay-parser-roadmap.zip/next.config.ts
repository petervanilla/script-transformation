import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // pdf-parse → pdfjs-dist dynamically imports a worker entry that Turbopack
  // mis-resolves when bundled. Keep these as runtime requires from node_modules.
  serverExternalPackages: ["pdf-parse", "pdfjs-dist", "mammoth"],
};

export default nextConfig;
