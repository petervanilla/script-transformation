"""Screenplay Parser — Phase 2 reference implementation (Python).

Raw Source (data/movies.md)
    ↓
Screenplay Parser (this package)
    ↓
Scene JSON  →  Beat Analyzer  →  Review screen

Pipeline stages:
    loaders.markdown_loader   — read raw file, detect encoding/line-endings, split movies
    parsers.scene_parser      — detect scene headings, group elements into scenes
    parsers.dialogue_parser   — classify character cues / parentheticals / dialogue
    parsers.transition_parser — classify transitions and montage blocks
    schemas.screenplay_schema — Pydantic models (strict JSON contract)
"""

__version__ = "0.1.0"
