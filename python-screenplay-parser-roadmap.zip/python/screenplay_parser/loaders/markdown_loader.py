"""markdown_loader — reads the raw source file and answers Phase 1 questions:

* Is it really Markdown or JSON?        (encoding / structure sniffing)
* Are movie separators consistent?      (detect_separator)
* What is the line-ending encoding?     (CRLF vs LF detection)
* Are there broken characters?          (replacement chars / private-use)
"""

from __future__ import annotations

import codecs
import re
from pathlib import Path
from typing import List, Optional, Tuple

_SEPARATORS = [
    (re.compile(r"^\*{3,}\s*$"), "***"),
    (re.compile(r"^-{3,}\s*$"), "---"),
    (re.compile(r"^={3,}\s*$"), "==="),
    (re.compile(r"^_{3,}\s*$"), "___"),
]


def is_separator_line(line: str) -> bool:
    s = line.strip()
    return any(pattern.match(s) for pattern, _ in _SEPARATORS)


def detect_separator(lines: List[str]) -> Optional[str]:
    for line in lines:
        if is_separator_line(line):
            stripped = line.strip()
            for pattern, label in _SEPARATORS:
                if pattern.match(stripped):
                    return label
    return None


def load_markdown(path: str) -> Tuple[str, List[str], dict]:
    """Read a screenplay markdown file.

    Returns (raw_text, lines, meta) where meta contains:
        file_size_bytes, encoding, line_endings, suspicious_chars, line_count
    """
    p = Path(path)
    data = p.read_bytes()
    meta: dict = {"file_size_bytes": len(data)}

    # ---- encoding detection (BOM aware) ----
    if data.startswith(codecs.BOM_UTF8):
        encoding = "utf-8-sig"
    elif data.startswith(codecs.BOM_UTF16_LE):
        encoding = "utf-16-le"
    elif data.startswith(codecs.BOM_UTF16_BE):
        encoding = "utf-16-be"
    else:
        encoding = "utf-8"
    try:
        text = data.decode(encoding)
    except UnicodeDecodeError:
        text = data.decode("utf-8", errors="replace")
        encoding = "utf-8 (with replacements)"
    meta["encoding"] = "utf-8" if "utf-8" in encoding else encoding

    # ---- line endings ----
    crlf = text.count("\r\n")
    lf = text.count("\n") - crlf
    meta["line_endings"] = "CRLF" if crlf > lf else ("LF" if lf > 0 else "none")
    meta["mixed_line_endings"] = crlf > 0 and lf > 0

    # ---- normalize for parsing ----
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    lines = text.split("\n")

    # ---- broken / suspicious characters ----
    suspicious = 0
    for ch in text:
        if ch == "\ufffd" or (0xE000 <= ord(ch) <= 0xF8FF):
            suspicious += 1
    meta["suspicious_chars"] = suspicious
    meta["line_count"] = len(lines)
    return text, lines, meta


def split_movies(lines: List[str]) -> List[Tuple[str, int, List[str]]]:
    """Split raw lines into movie chunks using separator lines.

    Returns a list of (title_hint, start_line_1based, chunk_lines).
    Separator lines themselves are dropped; chunks are NOT stripped of
    their title/credit header (that happens in the scene parser stage).
    """
    chunks: List[Tuple[str, int, List[str]]] = []
    current: List[str] = []
    current_start = 1
    title_hint = ""
    for idx, line in enumerate(lines, start=1):
        if is_separator_line(line):
            if current:
                chunks.append((title_hint, current_start, current))
            current = []
            current_start = idx + 1
            title_hint = ""
        else:
            if not current and line.strip():
                title_hint = line.strip()
            current.append(line)
    if current:
        chunks.append((title_hint, current_start, current))
    return chunks
