"""CLI entrypoint.

Usage:
    cd python
    python -m screenplay_parser.main ../data/movies.md --output screenplay_parser/output --diagnose

Produces:
    output/<first-movie-slug>.parsed.json   (Phase 2 output)
    output/dataset_report.json              (Phase 1 output, with --diagnose)
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import List

from .loaders.markdown_loader import (
    detect_separator,
    load_markdown,
    split_movies,
)
from .parsers.scene_parser import build_scenes, classify_line, is_scene_heading
from .schemas.screenplay_schema import DatasetReport, Movie, ParsedScreenplay


def slugify(title: str) -> str:
    s = re.sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return s or "untitled"


def parse_screenplay(raw: str, lines: List[str]) -> ParsedScreenplay:
    """Full Phase 2 pipeline: markdown → movies → scenes → elements."""
    chunks = split_movies(lines)
    movies: List[Movie] = []
    for title_hint, chunk_start, chunk in chunks:
        # --- split header (title/credits) from the body ---
        header_end = 0
        for i, line in enumerate(chunk):
            if is_scene_heading(line):
                header_end = i
                break
        header = chunk[:header_end]
        body = chunk[header_end:]

        title = next((ln.strip() for ln in header if ln.strip()), "UNTITLED")
        preamble: List = []
        for i, line in enumerate(header):
            el = classify_line(line, chunk_start + i)
            # keep only filmic markers (FADE IN: etc.) — drop title, credits, notes
            if el.type not in ("transition", "montage", "end_montage", "end_marker"):
                continue
            preamble.append(el)

        scenes = build_scenes(body, base_line=chunk_start + header_end)
        if scenes and preamble:
            scenes[0].elements = preamble + scenes[0].elements
            scenes[0].start_line = min(scenes[0].start_line, preamble[0].line)

        char_lines: dict = {}
        for sc in scenes:
            for el in sc.elements:
                if el.type == "character" and el.character:
                    char_lines[el.character] = char_lines.get(el.character, 0) + 1

        movies.append(
            Movie(
                title=title,
                slug=slugify(title),
                scenes=scenes,
                characters=sorted(char_lines),
                character_lines=char_lines,
                line_count=len(chunk),
            )
        )
    return ParsedScreenplay(
        movies=movies,
        total_scenes=sum(len(m.scenes) for m in movies),
        total_lines=len(lines),
    )


def diagnose(path: str) -> DatasetReport:
    """Phase 1 — file state diagnosis (dataset_report.json)."""
    raw, lines, meta = load_markdown(path)
    parsed = parse_screenplay(raw, lines)

    all_elements = [el for m in parsed.movies for sc in m.scenes for el in sc.elements]
    character_cues = sum(1 for el in all_elements if el.type == "character")
    dialogue_blocks = sum(1 for el in all_elements if el.type == "dialogue")
    transitions = sum(1 for el in all_elements if el.type == "transition")
    headings = [sc.heading for m in parsed.movies for sc in m.scenes]
    with_time = sum(1 for h in headings if re.search(r"\s-\s", h))

    seen: dict = {}
    duplicate_lines = 0
    for line in lines:
        s = line.strip()
        # short repeated lines (CUT TO:, SAM, ...) are normal in screenplays —
        # only flag meaningful duplicates (30+ chars) as a parsing risk.
        if len(s) > 30:
            seen[s] = seen.get(s, 0) + 1
    duplicate_lines = sum(max(0, c - 1) for c in seen.values())

    risks: List[str] = []
    if meta.get("mixed_line_endings"):
        risks.append("Line endings are mixed (CRLF + LF)")
    if meta.get("suspicious_chars", 0) > 0:
        risks.append(f"Suspicious characters found ({meta['suspicious_chars']})")
    if with_time < len(headings):
        risks.append(
            f"Some headings lack time information ({len(headings) - with_time} of {len(headings)})"
        )
    if character_cues > 0 and transitions > 0:
        risks.append("Character names may be confused with transitions")
    if parsed.movies == 1:
        risks.append("Single movie detected — movie separator may be missing")
    if duplicate_lines > 0:
        risks.append(f"Duplicate raw lines found ({duplicate_lines})")
    if not risks:
        risks.append("No critical parsing risks detected")

    separator = detect_separator(lines)
    return DatasetReport(
        movies=len(parsed.movies),
        scenes_detected=parsed.total_scenes,
        encoding=meta["encoding"],
        line_endings=meta["line_endings"],
        separator=separator,
        separator_consistent=separator is not None,
        heading_with_time=with_time,
        heading_without_time=len(headings) - with_time,
        character_cues=character_cues,
        dialogue_blocks=dialogue_blocks,
        transitions=transitions,
        duplicate_lines=duplicate_lines,
        suspicious_chars=meta["suspicious_chars"],
        file_size_bytes=meta["file_size_bytes"],
        line_count=meta["line_count"],
        parsing_risks=risks,
    )


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Screenplay Parser (Phase 2)")
    ap.add_argument("input", help="path to movies.md raw source")
    ap.add_argument("--output", default="screenplay_parser/output", help="output directory")
    ap.add_argument("--diagnose", action="store_true", help="also write dataset_report.json")
    args = ap.parse_args(argv)

    out_dir = Path(args.output)
    out_dir.mkdir(parents=True, exist_ok=True)

    raw, lines, _meta = load_markdown(args.input)
    parsed = parse_screenplay(raw, lines)
    slug = parsed.movies[0].slug if parsed.movies else "screenplay"
    out_file = out_dir / f"{slug}.parsed.json"
    out_file.write_text(
        json.dumps(parsed.model_dump(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(f"[ok] parsed {len(parsed.movies)} movies / {parsed.total_scenes} scenes")
    print(f"[ok] wrote {out_file}")

    if args.diagnose:
        report = diagnose(args.input)
        report_file = out_dir / "dataset_report.json"
        report_file.write_text(
            json.dumps(report.model_dump(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(f"[ok] wrote {report_file}")
        for risk in report.parsing_risks:
            print(f"[risk] {risk}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
