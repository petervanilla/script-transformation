"""scene_parser — detects scene headings and groups lines into Scene objects.

The parser is deliberately STATELESS and RULE-BASED. No camera work, no
emotion inference — those belong to later stages. This stage only answers:
"what is objectively in the text?" (Phase 2 scope)
"""

from __future__ import annotations

import re
from typing import List, Optional, Tuple

from ..schemas.screenplay_schema import Scene, ScreenplayElement
from .dialogue_parser import is_parenthetical, parse_character_cue
from .transition_parser import is_end_marker, is_end_montage, is_montage, is_transition

SCENE_HEADING_RE = re.compile(r"^(INT|EXT|INT\.EXT|INT\/EXT|I\/E|EST)\.?\s+(.+)$", re.IGNORECASE)


def is_scene_heading(line: str) -> bool:
    s = line.strip()
    if not s:
        return False
    s = re.sub(r"^#+\s*", "", s).strip()
    return bool(SCENE_HEADING_RE.match(s))


def parse_heading(heading: str) -> Tuple[Optional[str], Optional[bool], Optional[str]]:
    """Return (location, interior, time_of_day) from a scene heading."""
    h = re.sub(r"^#+\s*", "", heading.strip())
    m = SCENE_HEADING_RE.match(h)
    interior: Optional[bool] = None
    rest = h
    if m:
        prefix = m.group(1).upper()
        interior = prefix.startswith("INT") or prefix in ("I/E", "INT/EXT", "INT.EXT")
        rest = m.group(2).strip()
    parts = re.split(r"\s+-\s+", rest)
    if len(parts) >= 2:
        return parts[0].strip(), interior, parts[-1].strip()
    return rest.strip(), interior, None


def classify_line(line: str, line_no: int, in_montage: bool = False) -> ScreenplayElement:
    """Classify a single raw line into a ScreenplayElement."""
    stripped = line.strip()
    if not stripped:
        return ScreenplayElement(type="blank", text="", line=line_no)
    if is_scene_heading(stripped):
        return ScreenplayElement(type="scene_heading", text=stripped, line=line_no)
    if in_montage:
        if is_end_montage(stripped):
            return ScreenplayElement(type="end_montage", text=stripped, line=line_no)
        return ScreenplayElement(type="action", text=stripped, line=line_no)
    if is_montage(stripped):
        return ScreenplayElement(type="montage", text=stripped, line=line_no)
    if is_transition(stripped):
        return ScreenplayElement(type="transition", text=stripped, line=line_no)
    if is_end_marker(stripped):
        return ScreenplayElement(type="end_marker", text=stripped, line=line_no)
    if is_parenthetical(stripped):
        return ScreenplayElement(type="parenthetical", text=stripped, line=line_no)
    cue = parse_character_cue(stripped)
    if cue:
        name, ext = cue
        return ScreenplayElement(
            type="character", text=stripped, line=line_no, character=name, extension=ext
        )
    return ScreenplayElement(type="action", text=stripped, line=line_no)


def group_dialogue(elements: List[ScreenplayElement]) -> List[ScreenplayElement]:
    """After a character cue, fold parentheticals/actions into a dialogue block.

    A blank line ends the block, which keeps the following action paragraph
    from being swallowed as dialogue.
    """
    out: List[ScreenplayElement] = []
    i = 0
    n = len(elements)
    while i < n:
        el = elements[i]
        out.append(el)
        if el.type == "character":
            j = i + 1
            while j < n and elements[j].type in ("parenthetical", "action"):
                nxt = elements[j]
                out.append(
                    nxt
                    if nxt.type == "parenthetical"
                    else ScreenplayElement(type="dialogue", text=nxt.text, line=nxt.line)
                )
                j += 1
            i = j
            continue
        i += 1
    return out


def build_scenes(lines: List[str], base_line: int = 0) -> List[Scene]:
    """Group classified lines into Scene objects.

    base_line: 0-based offset so reported line numbers are absolute in the
    original file even when parsing a movie chunk.
    """
    scenes: List[Scene] = []
    heading_line: Optional[int] = None
    heading_text: Optional[str] = None
    elements: List[ScreenplayElement] = []
    in_montage = False

    def flush(last_line: int) -> None:
        nonlocal heading_line, heading_text, elements
        if heading_text is None:
            return
        grouped = [e for e in group_dialogue(elements) if e.type != "blank"]
        start = heading_line
        end = last_line
        raw = "\n".join(lines[start - 1 - base_line : end - base_line])
        location, interior, tod = parse_heading(heading_text)
        scenes.append(
            Scene(
                index=len(scenes) + 1,
                code=f"SC{len(scenes) + 1:03d}",
                heading=heading_text,
                location=location,
                interior=interior,
                time_of_day=tod,
                start_line=start,
                end_line=end,
                raw_text=raw,
                elements=grouped,
            )
        )
        heading_line = None
        heading_text = None
        elements = []

    for idx, line in enumerate(lines, start=1):
        el = classify_line(line, base_line + idx, in_montage)
        if el.type == "montage":
            in_montage = True
        elif el.type == "end_montage":
            in_montage = False
        if el.type == "scene_heading":
            flush(base_line + idx - 1)
            heading_line = base_line + idx
            heading_text = el.text
            elements = []
        elif heading_text is None:
            continue  # title/credit region — handled by main.py preamble logic
        else:
            elements.append(el)
    flush(base_line + len(lines))
    return scenes
