"""transition_parser — transitions, montage blocks and end markers."""

from __future__ import annotations

import re

_TRANSITION_RE = re.compile(
    r"^(FADE IN|FADE OUT|CUT TO|DISSOLVE TO|SMASH CUT TO|MATCH CUT TO|"
    r"WIPE TO|IRIS|HARD CUT TO|JUMP CUT TO|FADE TO BLACK)[.:]?\s*$",
    re.IGNORECASE,
)


def is_transition(line: str) -> bool:
    return bool(_TRANSITION_RE.match(line.strip()))


def is_montage(line: str) -> bool:
    return re.match(r"^MONTAGE\b", line.strip(), re.IGNORECASE) is not None


def is_end_montage(line: str) -> bool:
    return re.match(r"^END MONTAGE\b", line.strip(), re.IGNORECASE) is not None


def is_end_marker(line: str) -> bool:
    return line.strip().upper() == "THE END"
