"""dialogue_parser — character cues, parentheticals and dialogue blocks.

Heuristics (documented so the parser stays explainable):
* A character cue is a SHORT ALL-CAPS line, optionally followed by an
  extension in parentheses: SAM, RACHEL (O.S.), SAM (V.O.).
* A line that starts with "(" and ends with ")" is a parenthetical.
* Anything between a character cue and the next blank line is dialogue.
"""

from __future__ import annotations

import re
from typing import Optional, Tuple

_NAME_CHARS = "A-Z0-9 .'\\-"
_CUE_RE = re.compile(
    rf"([A-Z][{_NAME_CHARS}]{{0,28}}?)\s*(?:\(([A-Z0-9 .'\-]+)\))?\s*$"
)


def is_parenthetical(line: str) -> bool:
    s = line.strip()
    return s.startswith("(") and s.endswith(")") and len(s) > 2


def parse_character_cue(line: str) -> Optional[Tuple[str, Optional[str]]]:
    """Return (name, extension) if the line looks like a character cue."""
    s = line.strip()
    if not s or len(s) > 48:
        return None
    # A cue never contains an internal colon (TITLE CARD: ... is action).
    if ":" in s and not re.search(r"\([^)]+\)\s*$", s):
        return None
    m = _CUE_RE.match(s)
    if not m:
        return None
    name = m.group(1).strip()
    ext = m.group(2) if m.group(2) else None
    if not name or len(name) > 24:
        return None
    # All-caps sanity check: the name must contain no lowercase letters.
    if name != name.upper() or not any(c.isalpha() for c in name):
        return None
    return name, ext
