"""Pydantic schema — the strict JSON contract for the whole pipeline.

Design rule (Phase 3): never let the model describe freely. Every stage
of the pipeline must conform to a machine-checkable JSON Schema so that
parse results, beat analysis and shot plans can be validated and diffed.
"""

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class ScreenplayElement(BaseModel):
    """One classified line of the screenplay.

    type: scene_heading | action | character | dialogue | parenthetical
          | transition | montage | end_montage | end_marker | blank
    """

    type: str
    text: str
    line: int
    character: Optional[str] = None
    extension: Optional[str] = None  # V.O., O.S., CONT'D ...


class Scene(BaseModel):
    index: int
    code: str = Field(description="SC001, SC002 ... stable scene id")
    heading: str
    location: Optional[str] = None
    interior: Optional[bool] = None
    time_of_day: Optional[str] = None
    start_line: int
    end_line: int
    raw_text: str
    elements: List[ScreenplayElement] = Field(default_factory=list)


class Movie(BaseModel):
    title: str
    slug: str
    scenes: List[Scene] = Field(default_factory=list)
    characters: List[str] = Field(default_factory=list)
    character_lines: Dict[str, int] = Field(default_factory=dict)
    line_count: int = 0


class ParsedScreenplay(BaseModel):
    movies: List[Movie] = Field(default_factory=list)
    total_scenes: int = 0
    total_lines: int = 0


class DatasetReport(BaseModel):
    """Phase 1 output — file state diagnosis (dataset_report.json)."""

    movies: int
    scenes_detected: int
    encoding: str
    line_endings: str
    separator: Optional[str] = None
    separator_consistent: bool = True
    heading_with_time: int = 0
    heading_without_time: int = 0
    character_cues: int = 0
    dialogue_blocks: int = 0
    transitions: int = 0
    duplicate_lines: int = 0
    suspicious_chars: int = 0
    file_size_bytes: int = 0
    line_count: int = 0
    parsing_risks: List[str] = Field(default_factory=list)
