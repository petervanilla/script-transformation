"""Phase 4 — single-scene verification test.

Verifies the recommended test scene (INT. STARBUCKS - 7:30 A.M.) plus the
whole-dataset invariants:

* Scene separation is correct
* SAM and GEORGE are detected exactly
* Action and Dialogue never mix
* Beat-agnostic parsing is deterministic (stable output)
"""

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT / "python"))

from screenplay_parser.main import diagnose, parse_screenplay  # noqa: E402
from screenplay_parser.loaders.markdown_loader import load_markdown  # noqa: E402

DATA = ROOT / "data" / "movies.md"


class TestIAmSam(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        raw, lines, _meta = load_markdown(str(DATA))
        cls.raw = raw
        cls.lines = lines
        cls.parsed = parse_screenplay(raw, lines)
        cls.starbucks = next(
            sc
            for m in cls.parsed.movies
            for sc in m.scenes
            if sc.heading.startswith("INT. STARBUCKS")
        )

    # ---- Phase 1: dataset invariants ----
    def test_movie_count(self):
        self.assertEqual(len(self.parsed.movies), 2)

    def test_scene_count(self):
        self.assertEqual(self.parsed.total_scenes, 17)

    def test_stable_slugs(self):
        self.assertEqual(self.parsed.movies[0].slug, "a-piece-of-the-sun")
        self.assertEqual(self.parsed.movies[1].slug, "the-last-frame")

    # ---- Phase 2: parser correctness on the test scene ----
    def test_starbucks_heading(self):
        self.assertEqual(self.starbucks.location, "STARBUCKS")
        self.assertIs(self.starbucks.interior, True)
        self.assertEqual(self.starbucks.time_of_day, "7:30 A.M.")

    def test_sam_and_george_detected(self):
        names = [e.character for e in self.starbucks.elements if e.type == "character"]
        self.assertIn("SAM", names)
        self.assertIn("GEORGE", names)
        self.assertEqual(names.count("SAM"), 5)
        self.assertEqual(names.count("GEORGE"), 4)

    def test_action_and_dialogue_never_mix(self):
        types = [e.type for e in self.starbucks.elements]
        self.assertIn("action", types)
        self.assertIn("dialogue", types)
        for i, el in enumerate(self.starbucks.elements):
            if el.type == "character":
                nxt = self.starbucks.elements[i + 1]
                self.assertIn(nxt.type, ("parenthetical", "dialogue"))

    def test_no_dialogue_without_character(self):
        dialogue_count = sum(1 for e in self.starbucks.elements if e.type == "dialogue")
        cue_count = sum(1 for e in self.starbucks.elements if e.type == "character")
        self.assertGreaterEqual(dialogue_count, cue_count)

    def test_extensions_parsed(self):
        vo = [
            e.extension
            for m in self.parsed.movies
            for sc in m.scenes
            for e in sc.elements
            if e.type == "character" and e.extension
        ]
        self.assertIn("V.O.", vo)
        self.assertIn("O.S.", vo)

    def test_transitions_detected(self):
        transitions = [
            e.text
            for m in self.parsed.movies
            for sc in m.scenes
            for e in sc.elements
            if e.type == "transition"
        ]
        self.assertGreater(len(transitions), 6)
        self.assertIn("CUT TO:", transitions)
        self.assertIn("SMASH CUT TO:", transitions)

    def test_montage_block(self):
        montage = next(
            sc for sc in self.parsed.movies[0].scenes if sc.location == "CITY STREET"
        )
        types = [e.type for e in montage.elements]
        self.assertEqual(types[0], "montage")
        self.assertIn("end_montage", types)

    # ---- Phase 1: report ----
    def test_report_shape(self):
        report = diagnose(str(DATA))
        self.assertEqual(report.movies, 2)
        self.assertEqual(report.scenes_detected, 17)
        self.assertEqual(report.encoding, "utf-8")
        self.assertEqual(report.line_endings, "LF")
        self.assertEqual(report.separator, "***")
        self.assertGreater(report.character_cues, 20)
        self.assertIsInstance(report.parsing_risks, list)


if __name__ == "__main__":
    unittest.main(verbosity=2)
