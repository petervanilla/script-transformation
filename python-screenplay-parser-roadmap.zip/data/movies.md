A PIECE OF THE SUN
Written for the Director Dataset — Sample Screenplay

FADE IN:

INT. STARBUCKS - 7:30 A.M.

Early morning light cuts through the glass. The shop is half
empty. Behind the counter, SAM - a man in his late thirties
with bright, unguarded eyes - works the register.

SAM
(cheerful, rehearsed)
Welcome to Starbucks. What can I get for you today?

GEORGE, a regular in a rumpled trench coat, steps forward.

GEORGE
The usual, Sam. Venti black. No room.

SAM
(concentrating hard)
Venti... black. No room. Got it.

Sam turns to the machine. His hands move slowly, methodically,
sorting packets of sweetener into neat rows. He counts them,
then counts again.

GEORGE
You know, you're the only one here who remembers my order
without me saying it twice.

SAM
I write it down. In here.
(taps his temple)
Then I practice it. So I don't forget.

GEORGE
That's more than most people do.

SAM
(beaming)
Thank you, George.

Sam hands over the cup. Their fingers almost touch. George
pays, takes the cup, and pauses at the door.

GEORGE
See you tomorrow, Sam.

SAM
Tomorrow. Same time. I'll be here.

CUT TO:

EXT. CITY STREET - DAY

MONTAGE

A) Sam walks LUCY, age seven, to school. She holds his hand
and swings it like a pendulum.

B) Sam recites his script at a bus stop: "Good morning. The
bus is late. That's okay."

C) Lucy draws a sun on Sam's palm with a marker. Sam stares
at it all day.

D) At the coffee shop, Sam lines up cups in perfect rows.
The manager watches, worried.

END MONTAGE

CUT TO:

INT. LUCY'S BEDROOM - CONTINUOUS

Lucy's room is a riot of crayons and cardboard planets.
LUCY (7), all knees and elbows, tries to tie her shoelaces.
Sam kneels beside her, patient.

SAM
Loop, swoop, and pull. Like a rabbit going into a hole.

Lucy's laces end up in a knot. She looks at Sam.

LUCY
Daddy, you do it. You're faster.

SAM
(shaking his head)
No. You practice. I practice. We both get better.

Lucy sighs, then tries again. Her face scrunches with focus.
Sam watches her, his pride unmistakable. The knot, this time,
holds.

LUCY
(leaping up)
I did it!

Sam lifts her onto his shoulders. She spreads her arms wide.

LUCY
I'm an airplane, Daddy. Fly me to the moon.

Sam runs around the room, making engine noises. Lucy laughs,
her fingers gripping his hair.

CUT TO:

EXT. SCHOOL PLAYGROUND - LATER

Lunch recess. Kids swarm the jungle gym. Lucy sits alone on a
bench with a comic book. RITA, a teacher with tired eyes,
watches from the doorway. ANNIE, another mother, joins her.

ANNIE
Is that Sam's daughter? The one who still believes in
imaginary friends?

RITA
(quietly)
She has a good imagination. That's not a crime.

ANNIE
She's seven, Rita. She should be playing with the others,
not babysitting her father's feelings.

LUCY
(without looking up)
I can hear you, you know.

ANNIE reddens. Rita walks over and sits beside Lucy.

RITA
What are you reading?

LUCY
A comic. The hero saves his dad from a falling star.

RITA
Sounds like a good hero.

LUCY
Yeah. He practices. Every day. So he never forgets how.

KIDS shout in the distance. Lucy turns back to her book.

CUT TO:

INT. APARTMENT - NIGHT

A small apartment, tidy but cluttered with Lucy's art. The TV
murmurs. Sam folds laundry into perfect squares.

A knock at the door. Sam checks the peephole and freezes.

RACHEL (O.S.)
Sam. It's me. Please open the door.

Sam opens it a crack. RACHEL - polished, worn out - stands in
the hallway with a folder in her hands.

RACHEL
I need to talk about Lucy.

SAM
(guarded)
Lucy is sleeping.

RACHEL
Sam, the school called me. They said she's not fitting in.
They said - (beat) - they suggested I take her for a while.

SAM
(shaking his head)
No. No, she's mine. I take care of her. I know the
answers to all her questions.

RACHEL
(voice breaking)
I know you love her. I know. But love isn't enough,
Sam. She needs more than love.

Sam's hands tremble. He grips the doorframe, knuckles white.

SAM
(small voice)
Love is all I have.

RACHEL
(almost whispering)
That's what scares me.

She leaves the folder on the table and walks out. Sam stares
at the door long after it closes.

FADE OUT.

INT. COFFEE SHOP - NEXT DAY

Sam wipes the same table four times. The morning crowd
buzzes around him, invisible. His lips move silently.

SAM (V.O.)
My name is Sam Dawson. I like the Beatles. I collect
comic books. I can tie my shoes and make toast and
count change.

He counts a stack of sugar packets. One, two, three -
he loses his place, starts again.

SAM (V.O.)
Lucy's teacher says she has a good brain. My brain is
small, but it's full. I keep the things I love in it.
Like a box. A very safe box.

GEORGE slides onto his stool.

GEORGE
You're counting again, Sam. You're going to wear the
numbers out.

SAM
(snapping back to the world)
George! Venti black. No room. Coming right up.

CUT TO:

EXT. PARK - AFTERNOON

Lucy swings higher and higher. Sam stands at the base of the
swing set, one hand raised, ready to catch.

LUCY
Higher, Daddy! Push me higher!

SAM
You're already higher than the trees!

A CRACK - loud, splitting - cuts the air. Sam's head whips
around. A chain has snapped on the far swings, out of frame,
rattling against the pole. Two teenagers laugh as they kick
the broken chain.

SAM
(relieved, exhaling)
Okay. Okay. It's okay.

He turns back to Lucy. His hand shakes a little as he reaches
for the swing.

LUCY
Daddy, are you scared?

SAM
(steadying himself)
No. I'm practicing being brave. You can practice too.

DISSOLVE TO:

INT. LAW OFFICE - DAY

A cramped office full of files. JACK, a lawyer with a suit
that doesn't quite fit, hums along to a Beatles song on a
tiny radio. SAM sits across from him, gripping a paper cup.

The song: "All You Need Is Love." Jack turns it up.

JACK
You know this one?

SAM
(nodding hard)
Yes. I know all their songs. Paul wrote it. It's about
the thing my daughter gives me.

JACK
Which is?

SAM
Love. See? Love is all you need. So I have everything.

Jack looks at Sam, then at the custody papers on his desk.
He turns the radio down.

JACK
Sam, the court is going to ask you things. Hard things.
I'm going to teach you the answers. But you have to
practice them, the way you practice your coffee counts.

SAM
I'm good at practicing.

JACK
(small, honest smile)
Yeah. I'm starting to believe that.

SMASH CUT TO:

INT. APARTMENT - MORNING

TITLE CARD: THREE YEARS LATER

The same apartment, transformed. Lucy's art now covers the
walls in careful frames. LUCY, now ten, pours cereal with
measured precision, counting each spoonful. Sam, in a bus
driver's uniform, checks his watch.

SAM
Fourteen minutes. Perfect. That's a new record.

LUCY
You said that yesterday.

SAM
That's why it's a record. Records get broken.

Lucy laughs - the same laugh, but older. She hands him his
lunch bag, packed in neat rows.

LUCY
I put a note in there. Don't read it at work.

SAM
(pocketing it carefully)
I'll read it at my break. I'll practice the words first.

CUT TO:

EXT. BUS STOP - DUSK

Rain. Sam waits under the shelter, cap pulled low. His bus
pulls up. He boards without a word.

CUT TO:

INT. DINER - NIGHT

Sam sits in a booth, the note from Lucy open on the table.
His lips move as he reads it to himself, slowly.

SAM
(to himself)
"Dear Daddy. You don't have to practice being my dad.
You're already the best one."

The WAITRESS refills his coffee. She glances at the note.

WAITRESS
Somebody loves you a lot.

SAM
(smiling, eyes wet)
Yes. Her name is Lucy.

FADE OUT.

INT. HOSPITAL WAITING ROOM - DAY

Fluorescent lights. Sam paces the length of the room, counts
the tiles, starts again. RITA sits with her coat half-on.

RITA
Sam, sit down. She's just getting stitches. She'll be
fine.

SAM
I counted the tiles. Forty-seven. Last time it was
forty-seven. That's good, right? Forty-seven is a
lucky number.

RITA
(gently)
She fell off the monkey bars, Sam. It happens to every
kid. It's not your fault.

SAM
(stops pacing)
But I wasn't there. I was driving the bus. I should
have been there.

RITA
You can't be everywhere. Nobody can.

A DOCTOR appears at the door. Sam's whole body tenses.

DOCTOR
Mr. Dawson? Lucy's ready. She's asking for you.

Sam is gone before the sentence finishes.

CUT TO:

INT. COURTROOM - DAY

Wood paneling, hushed voices. Sam sits at the table, fingers
laced tight. RACHEL testifies from the stand.

RACHEL
I don't say this lightly. I love my daughter. But Sam
can't drive her to emergencies. He can't understand her
homework. He can't - (she stops) - he can't be her
whole world when he can barely manage his own.

The JUDGE turns to Sam.

JUDGE
Mr. Dawson, do you understand what's being asked today?

SAM
(standing, voice shaking)
Yes, Your Honor. They want to take Lucy away because
my brain is small.

JUDGE
That's not what we're here to decide.

SAM
Then what are you here to decide? Because she loves
me. And I love her. Love is all you need. Paul McCartney
said so, and he's not even in this room.

A ripple of laughter. Even the judge hides a smile.

JUDGE
(clearing throat)
Mr. Dawson, I think we need to talk about what Lucy
needs - and what she wants.

CUT TO:

EXT. BEACH - SUNSET

The tide pulls back, leaving a mirror of sky. Sam and Lucy
walk barefoot along the waterline. Her hand in his, swung
like a pendulum, the way it's always been.

LUCY
Daddy, when I grow up, I'm going to take care of you.

SAM
I'm going to practice being old so you don't have to
work too hard.

LUCY
(laughing)
That's not how it works.

SAM
Then I'll practice the right way.

She stops, turns, and wraps her arms around him. The sun
drops into the sea. Sam holds her like she's made of glass -
no, like she's made of everything.

FADE OUT.

THE END

***

THE LAST FRAME

INT. DARKROOM - NIGHT

Red light. Trays of chemicals. MAYA, sixty, lowers a
photograph into the developer with the reverence of a
prayer. An image blooms: a boy on a bicycle, mid-jump,
caught forever.

MAYA
(whispering)
There you are.

EXT. ROOFTOP - DAWN

Maya pins her prints to a clothesline. The wind lifts them
like wings. A MAN in a suit watches from the rooftop door.

MAN
The gallery called. They want your retrospective.
Forty years of work.

MAYA
(not turning)
I don't photograph the past. I photograph what I can't
keep.

INT. GALLERY - DAY

The walls are covered in Maya's prints. Crowds drift past.
In the center of the room, the boy on the bicycle - enlarged,
framed, glowing. Maya stands before it. The man from the
rooftop places a hand on her shoulder.

MAN
You kept it after all.

MAYA
(smiling)
No. I shared it.

FADE OUT.
